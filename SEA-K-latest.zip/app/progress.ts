import {
  cardById,
  cards,
  decorItems,
  explorationSpots,
  regionRewards,
  tradeListings,
} from "./data";
import type {
  CardPack,
  DecorItem,
  ExplorationSpot,
  Rarity,
  RegionReward,
  RegionId,
  SeaCard,
  TradeListing,
} from "./data";

export const STORAGE_KEY = "sea-k-progress";

const PROGRESS_VERSION = 2 as const;

export interface ProgressState {
  version: typeof PROGRESS_VERSION;
  coins: number;
  cards: Record<string, number>;
  verifications: Record<string, string>;
  completedTrades: string[];
  ownedDecor: string[];
  activeFrame: string | null;
  activeBackground: string | null;
  cardPhotos: Record<string, string>;
  photoCaptures: Record<string, string>;
  ownedRewards: string[];
  onboardingSeen: boolean;
}

/**
 * A small, trade-friendly starter collection makes every part of the demo
 * reachable without pretending that the visitor has already completed spots.
 */
export const DEFAULT_PROGRESS: ProgressState = {
  version: PROGRESS_VERSION,
  coins: 480,
  cards: {
    "haeundae-foam-letter": 2,
    "gwangalli-night-current": 2,
    "yeongdo-container-sparks": 1,
    "dadaepo-orange-horizon": 1,
    "gijang-seaweed-forest": 1,
  },
  verifications: {},
  completedTrades: [],
  ownedDecor: [],
  activeFrame: null,
  activeBackground: null,
  cardPhotos: {},
  photoCaptures: {},
  ownedRewards: [],
  onboardingSeen: false,
};

type RandomSource = () => number;

export type VerifySpotResult =
  | {
      ok: true;
      state: ProgressState;
      card: SeaCard;
      coins: number;
    }
  | { ok: false; reason: string };

export type BuyPackResult =
  | { ok: true; state: ProgressState; card: SeaCard }
  | { ok: false; reason: string };

export type BuyOrEquipDecorResult =
  | {
      ok: true;
      state: ProgressState;
      action: "purchased" | "equipped";
    }
  | { ok: false; reason: string };

export type CompleteTradeResult =
  | {
      ok: true;
      state: ProgressState;
      receivedCard: SeaCard;
      coins: number;
    }
  | { ok: false; reason: string };

export type CaptureCardResult =
  | {
      ok: true;
      state: ProgressState;
      coins: number;
      isFirstCapture: boolean;
    }
  | { ok: false; reason: string };

export type RedeemRegionRewardResult =
  | { ok: true; state: ProgressState }
  | { ok: false; reason: string };

const explorationRarityWeights: Record<Rarity, number> = {
  Common: 60,
  Rare: 27,
  Epic: 10,
  Legendary: 3,
};

const knownCardIds = new Set(cards.map((card) => card.id));
const knownDecorIds = new Set(decorItems.map((item) => item.id));
const knownSpotIds = new Set(explorationSpots.map((spot) => spot.id));
const knownTradeIds = new Set(tradeListings.map((listing) => listing.id));
const knownRewardIds = new Set(regionRewards.map((reward) => reward.id));

function cloneDefaultProgress(): ProgressState {
  return {
    ...DEFAULT_PROGRESS,
    cards: { ...DEFAULT_PROGRESS.cards },
    verifications: { ...DEFAULT_PROGRESS.verifications },
    completedTrades: [...DEFAULT_PROGRESS.completedTrades],
    ownedDecor: [...DEFAULT_PROGRESS.ownedDecor],
    cardPhotos: { ...DEFAULT_PROGRESS.cardPhotos },
    photoCaptures: { ...DEFAULT_PROGRESS.photoCaptures },
    ownedRewards: [...DEFAULT_PROGRESS.ownedRewards],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function toNonNegativeInteger(value: unknown, fallback: number): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
    return fallback;
  }

  return Math.min(Math.floor(value), Number.MAX_SAFE_INTEGER);
}

function uniqueStrings(value: unknown): string[] | null {
  if (!Array.isArray(value)) {
    return null;
  }

  return [...new Set(value.filter((entry): entry is string => typeof entry === "string"))];
}

function isLocalDateKey(value: unknown): value is string {
  if (typeof value !== "string") {
    return false;
  }

  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) {
    return false;
  }

  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const candidate = new Date(year, month - 1, day);
  return (
    candidate.getFullYear() === year &&
    candidate.getMonth() === month - 1 &&
    candidate.getDate() === day
  );
}

function isSupportedPhotoDataUrl(value: unknown): value is string {
  if (typeof value !== "string") {
    return false;
  }

  const match = /^data:image\/(?:jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(value);
  if (!match) {
    return false;
  }

  const payload = match[1];
  if (payload.length % 4 === 1) {
    return false;
  }

  try {
    const decoded = atob(payload);
    return btoa(decoded).replace(/=+$/, "") === payload.replace(/=+$/, "");
  } catch {
    return false;
  }
}

function normalizeRandom(random: RandomSource): number {
  const value = random();
  if (!Number.isFinite(value)) {
    return 0;
  }

  return Math.min(Math.max(value, 0), 1 - Number.EPSILON);
}

function randomInteger(min: number, max: number, random: RandomSource): number {
  const lower = Math.ceil(Math.min(min, max));
  const upper = Math.floor(Math.max(min, max));
  return lower + Math.floor(normalizeRandom(random) * (upper - lower + 1));
}

function chooseOne<T>(items: readonly T[], random: RandomSource): T | null {
  if (items.length === 0) {
    return null;
  }

  return items[Math.floor(normalizeRandom(random) * items.length)] ?? null;
}

function chooseWeightedRarity(
  weights: Readonly<Record<Rarity, number>>,
  availableRarities: readonly Rarity[],
  random: RandomSource,
): Rarity | null {
  const available = new Set(availableRarities);
  const entries = (Object.entries(weights) as [Rarity, number][]).filter(
    ([rarity, weight]) => available.has(rarity) && Number.isFinite(weight) && weight > 0,
  );

  const total = entries.reduce((sum, [, weight]) => sum + weight, 0);
  if (total <= 0) {
    return null;
  }

  let cursor = normalizeRandom(random) * total;
  for (const [rarity, weight] of entries) {
    cursor -= weight;
    if (cursor < 0) {
      return rarity;
    }
  }

  return entries.at(-1)?.[0] ?? null;
}

function addCard(
  collection: Readonly<Record<string, number>>,
  cardId: string,
): Record<string, number> {
  return {
    ...collection,
    [cardId]: (collection[cardId] ?? 0) + 1,
  };
}

/** Returns a YYYY-MM-DD key using the visitor's local calendar date. */
export function getLocalDateKey(date: Date = new Date()): string {
  if (Number.isNaN(date.getTime())) {
    throw new RangeError("유효한 날짜가 필요해요.");
  }

  const year = String(date.getFullYear()).padStart(4, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

/**
 * Safely parses persisted JSON (or an already parsed value), migrates partial
 * legacy state, and drops unknown/corrupt collection entries.
 */
export function safeParseProgress(value: unknown): ProgressState {
  let parsed: unknown = value;

  if (typeof value === "string") {
    try {
      parsed = JSON.parse(value) as unknown;
    } catch {
      return cloneDefaultProgress();
    }
  }

  if (!isRecord(parsed)) {
    return cloneDefaultProgress();
  }

  const parsedCards: Record<string, number> = {};
  if (isRecord(parsed.cards)) {
    for (const [cardId, count] of Object.entries(parsed.cards)) {
      if (!knownCardIds.has(cardId)) {
        continue;
      }

      const normalizedCount = toNonNegativeInteger(count, 0);
      if (normalizedCount > 0) {
        parsedCards[cardId] = normalizedCount;
      }
    }
  }

  const parsedVerifications: Record<string, string> = {};
  if (isRecord(parsed.verifications)) {
    for (const [placeId, dateKey] of Object.entries(parsed.verifications)) {
      if (knownSpotIds.has(placeId) && isLocalDateKey(dateKey)) {
        parsedVerifications[placeId] = dateKey;
      }
    }
  }

  const completedTrades = (uniqueStrings(parsed.completedTrades) ?? []).filter((id) =>
    knownTradeIds.has(id),
  );
  const ownedDecor = (uniqueStrings(parsed.ownedDecor) ?? []).filter((id) =>
    knownDecorIds.has(id),
  );

  const cardPhotos: Record<string, string> = {};
  if (isRecord(parsed.cardPhotos)) {
    for (const [cardId, photoDataUrl] of Object.entries(parsed.cardPhotos)) {
      if (knownCardIds.has(cardId) && isSupportedPhotoDataUrl(photoDataUrl)) {
        cardPhotos[cardId] = photoDataUrl;
      }
    }
  }

  const photoCaptures: Record<string, string> = {};
  if (isRecord(parsed.photoCaptures)) {
    for (const [cardId, dateKey] of Object.entries(parsed.photoCaptures)) {
      if (knownCardIds.has(cardId) && isLocalDateKey(dateKey)) {
        photoCaptures[cardId] = dateKey;
      }
    }
  }

  const ownedRewards = (uniqueStrings(parsed.ownedRewards) ?? []).filter((id) =>
    knownRewardIds.has(id),
  );

  const activeFrame =
    typeof parsed.activeFrame === "string" && ownedDecor.includes(parsed.activeFrame)
      ? parsed.activeFrame
      : null;
  const activeBackground =
    typeof parsed.activeBackground === "string" && ownedDecor.includes(parsed.activeBackground)
      ? parsed.activeBackground
      : null;

  return {
    version: PROGRESS_VERSION,
    coins: toNonNegativeInteger(parsed.coins, DEFAULT_PROGRESS.coins),
    cards: isRecord(parsed.cards) ? parsedCards : { ...DEFAULT_PROGRESS.cards },
    verifications: isRecord(parsed.verifications) ? parsedVerifications : {},
    completedTrades,
    ownedDecor,
    activeFrame,
    activeBackground,
    cardPhotos,
    photoCaptures,
    ownedRewards,
    onboardingSeen: parsed.onboardingSeen === true,
  };
}

/** Stores a visitor photo and grants the card reward only on its first capture. */
export function captureCard(
  state: ProgressState,
  card: SeaCard,
  photoDataUrl: string,
  coins: number,
  date: Date = new Date(),
  spotId?: string,
): CaptureCardResult {
  if (!knownCardIds.has(card.id)) {
    return { ok: false, reason: "알 수 없는 카드입니다." };
  }

  if (!isSupportedPhotoDataUrl(photoDataUrl)) {
    return {
      ok: false,
      reason: "JPEG, PNG 또는 WebP 형식의 올바른 사진을 선택해 주세요.",
    };
  }

  if (typeof coins !== "number" || !Number.isFinite(coins) || coins < 0) {
    return { ok: false, reason: "코인 보상이 올바르지 않습니다." };
  }

  let dateKey: string;
  try {
    dateKey = getLocalDateKey(date);
  } catch {
    return { ok: false, reason: "촬영 날짜가 올바르지 않습니다." };
  }

  const isFirstCapture =
    !Object.hasOwn(state.cardPhotos, card.id) &&
    !Object.hasOwn(state.photoCaptures, card.id);

  if (spotId && !knownSpotIds.has(spotId)) {
    return { ok: false, reason: "알 수 없는 탐험 장소입니다." };
  }

  if (spotId && state.verifications[spotId] === dateKey) {
    return {
      ok: false,
      reason: "오늘은 이미 이 장소에서 카드를 획득했어요. 내일 다시 탐험해 주세요.",
    };
  }

  const earnedCoins = isFirstCapture
    ? Math.min(Math.floor(coins), Number.MAX_SAFE_INTEGER)
    : 0;

  const nextState: ProgressState = {
    ...state,
    coins: state.coins + earnedCoins,
    cards: isFirstCapture ? addCard(state.cards, card.id) : { ...state.cards },
    verifications:
      spotId
        ? { ...state.verifications, [spotId]: dateKey }
        : { ...state.verifications },
    completedTrades: [...state.completedTrades],
    ownedDecor: [...state.ownedDecor],
    cardPhotos: {
      ...state.cardPhotos,
      [card.id]: photoDataUrl,
    },
    photoCaptures: {
      ...state.photoCaptures,
      [card.id]: dateKey,
    },
    ownedRewards: [...state.ownedRewards],
  };

  return { ok: true, state: nextState, coins: earnedCoins, isFirstCapture };
}

/** Exchanges coins for a local demo reward, once per reward. */
export function redeemRegionReward(
  state: ProgressState,
  reward: RegionReward,
): RedeemRegionRewardResult {
  const knownReward = regionRewards.find((candidate) => candidate.id === reward.id);
  if (!knownReward) {
    return { ok: false, reason: "알 수 없는 지역 보상입니다." };
  }

  if (state.ownedRewards.includes(knownReward.id)) {
    return { ok: false, reason: "이미 교환한 지역 보상입니다." };
  }

  if (state.coins < knownReward.price) {
    return { ok: false, reason: "코인이 부족합니다." };
  }

  return {
    ok: true,
    state: {
      ...state,
      coins: state.coins - knownReward.price,
      cards: { ...state.cards },
      verifications: { ...state.verifications },
      completedTrades: [...state.completedTrades],
      ownedDecor: [...state.ownedDecor],
      cardPhotos: { ...state.cardPhotos },
      photoCaptures: { ...state.photoCaptures },
      ownedRewards: [...state.ownedRewards, knownReward.id],
    },
  };
}

export function markOnboardingSeen(state: ProgressState): ProgressState {
  return {
    ...state,
    cards: { ...state.cards },
    verifications: { ...state.verifications },
    completedTrades: [...state.completedTrades],
    ownedDecor: [...state.ownedDecor],
    cardPhotos: { ...state.cardPhotos },
    photoCaptures: { ...state.photoCaptures },
    ownedRewards: [...state.ownedRewards],
    onboardingSeen: true,
  };
}

export function drawRegionCard(
  regionId: RegionId,
  allowedRarities: readonly Rarity[],
  random: RandomSource = Math.random,
): SeaCard {
  const regionCards = cards.filter((card) => card.regionId === regionId);
  const availableRarities = allowedRarities.filter((rarity) =>
    regionCards.some((card) => card.rarity === rarity),
  );
  const rarity = chooseWeightedRarity(
    explorationRarityWeights,
    availableRarities,
    random,
  );
  const candidates = rarity
    ? regionCards.filter((card) => card.rarity === rarity)
    : regionCards;
  const selected = chooseOne(candidates, random);

  if (!selected) {
    throw new Error(`지역 카드 데이터를 찾을 수 없어요: ${regionId}`);
  }

  return selected;
}

export function drawPackCard(
  pack: CardPack,
  random: RandomSource = Math.random,
): SeaCard {
  const availableRarities = [...new Set(cards.map((card) => card.rarity))];
  const rarity = chooseWeightedRarity(pack.rarityWeights, availableRarities, random);
  const candidates = rarity ? cards.filter((card) => card.rarity === rarity) : cards;
  const selected = chooseOne(candidates, random);

  if (!selected) {
    throw new Error("카드팩에 넣을 카드 데이터가 없어요.");
  }

  return selected;
}

export function verifySpot(
  state: ProgressState,
  spot: ExplorationSpot,
  date: Date = new Date(),
  random: RandomSource = Math.random,
): VerifySpotResult {
  const dateKey = getLocalDateKey(date);
  if (state.verifications[spot.id] === dateKey) {
    return { ok: false, reason: "오늘은 이미 이 장소를 인증했어요." };
  }

  const card = drawRegionCard(spot.regionId, spot.possibleRarities, random);
  const coins = randomInteger(
    spot.coinReward.min,
    spot.coinReward.max,
    random,
  );
  const nextState: ProgressState = {
    ...state,
    coins: state.coins + coins,
    cards: addCard(state.cards, card.id),
    verifications: {
      ...state.verifications,
      [spot.id]: dateKey,
    },
    completedTrades: [...state.completedTrades],
    ownedDecor: [...state.ownedDecor],
    cardPhotos: { ...state.cardPhotos },
    photoCaptures: { ...state.photoCaptures },
    ownedRewards: [...state.ownedRewards],
  };

  return { ok: true, state: nextState, card, coins };
}

export function buyPack(
  state: ProgressState,
  pack: CardPack,
  random: RandomSource = Math.random,
): BuyPackResult {
  if (state.coins < pack.price) {
    return { ok: false, reason: "코인이 부족해요." };
  }

  const card = drawPackCard(pack, random);
  const nextState: ProgressState = {
    ...state,
    coins: state.coins - pack.price,
    cards: addCard(state.cards, card.id),
    verifications: { ...state.verifications },
    completedTrades: [...state.completedTrades],
    ownedDecor: [...state.ownedDecor],
    cardPhotos: { ...state.cardPhotos },
    photoCaptures: { ...state.photoCaptures },
    ownedRewards: [...state.ownedRewards],
  };

  return { ok: true, state: nextState, card };
}

export function buyOrEquipDecor(
  state: ProgressState,
  item: DecorItem,
): BuyOrEquipDecorResult {
  const isOwned = state.ownedDecor.includes(item.id);
  if (!isOwned && state.coins < item.price) {
    return { ok: false, reason: "코인이 부족해요." };
  }

  const activeKey =
    item.decorType === "frame" ? "activeFrame" : "activeBackground";
  const nextState: ProgressState = {
    ...state,
    coins: isOwned ? state.coins : state.coins - item.price,
    cards: { ...state.cards },
    verifications: { ...state.verifications },
    completedTrades: [...state.completedTrades],
    ownedDecor: isOwned ? [...state.ownedDecor] : [...state.ownedDecor, item.id],
    cardPhotos: { ...state.cardPhotos },
    photoCaptures: { ...state.photoCaptures },
    ownedRewards: [...state.ownedRewards],
    [activeKey]: item.id,
  };

  return {
    ok: true,
    state: nextState,
    action: isOwned ? "equipped" : "purchased",
  };
}

export function completeTrade(
  state: ProgressState,
  listing: TradeListing,
): CompleteTradeResult {
  if (state.completedTrades.includes(listing.id)) {
    return { ok: false, reason: "이미 완료한 교환이에요." };
  }

  if ((state.cards[listing.wantedCardId] ?? 0) < 1) {
    return { ok: false, reason: "교환에 필요한 카드를 보유하고 있지 않아요." };
  }

  const receivedCard = cardById[listing.offeredCardId];
  if (!receivedCard) {
    return { ok: false, reason: "받을 카드 정보를 찾을 수 없어요." };
  }

  const nextCards = { ...state.cards };
  const remaining = nextCards[listing.wantedCardId] - 1;
  if (remaining > 0) {
    nextCards[listing.wantedCardId] = remaining;
  } else {
    delete nextCards[listing.wantedCardId];
  }
  nextCards[receivedCard.id] = (nextCards[receivedCard.id] ?? 0) + 1;

  const coins = Math.max(0, Math.floor(listing.bonusCoins));
  const nextState: ProgressState = {
    ...state,
    coins: state.coins + coins,
    cards: nextCards,
    verifications: { ...state.verifications },
    completedTrades: [...state.completedTrades, listing.id],
    ownedDecor: [...state.ownedDecor],
    cardPhotos: { ...state.cardPhotos },
    photoCaptures: { ...state.photoCaptures },
    ownedRewards: [...state.ownedRewards],
  };

  return { ok: true, state: nextState, receivedCard, coins };
}
