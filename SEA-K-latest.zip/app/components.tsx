"use client";

import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import {
  rarityMeta,
  regionById,
  type Rarity,
  type SeaCard,
} from "./data";

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand--compact" : ""}`} aria-label="SEA:K">
      <span>SEA</span>
      <span className="brand__colon" aria-hidden="true">
        <i />
        <i />
      </span>
      <span>K</span>
    </div>
  );
}

export function Coin({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  return (
    <span className={`coin coin--${size}`} aria-hidden="true">
      <span>₵</span>
    </span>
  );
}

export function RarityBadge({ rarity }: { rarity: Rarity }) {
  return (
    <span
      className="rarity-badge"
      data-rarity={rarity.toLowerCase()}
      style={{ "--rarity-color": rarityMeta[rarity].color } as CSSProperties}
    >
      <i aria-hidden="true" />
      {rarityMeta[rarity].label}
    </span>
  );
}

export function CardArtwork({
  card,
  locked = false,
  photo,
}: {
  card: SeaCard;
  locked?: boolean;
  photo?: string;
}) {
  const style = {
    "--art-a": card.visual.gradient[0],
    "--art-b": card.visual.gradient[1],
    "--art-c": card.visual.gradient[2],
    "--art-glow": card.visual.glow,
  } as CSSProperties;

  return (
    <div
      className="card-artwork"
      data-locked={locked || undefined}
      data-photo={photo ? "true" : undefined}
      style={style}
      aria-hidden="true"
    >
      {photo && (
        // 사용자가 직접 촬영한 로컬 data URL이므로 최적화 서버를 거치지 않습니다.
        // eslint-disable-next-line @next/next/no-img-element
        <img className="card-artwork__photo" src={photo} alt="" />
      )}
      <div className="card-artwork__contours" />
      <div className="card-artwork__orb" />
      <div className="card-artwork__horizon" />
      <span className="card-artwork__glyph">{locked ? "?" : card.visual.glyph}</span>
      <div className="card-artwork__wave card-artwork__wave--back" />
      <div className="card-artwork__wave card-artwork__wave--front" />
      {!locked && (
        <>
          <i className="card-artwork__spark card-artwork__spark--one" />
          <i className="card-artwork__spark card-artwork__spark--two" />
        </>
      )}
    </div>
  );
}

export function SeaCardTile({
  card,
  owned = 0,
  compact = false,
  activeFrame,
  photo,
  onClick,
  label,
}: {
  card: SeaCard;
  owned?: number;
  compact?: boolean;
  activeFrame?: string | null;
  photo?: string;
  onClick?: () => void;
  label?: string;
}) {
  const isOwned = owned > 0;
  const region = regionById[card.regionId];
  const content = (
    <article
      className={`sea-card ${compact ? "sea-card--compact" : ""} ${activeFrame ? `sea-card--${activeFrame}` : ""}`}
      data-rarity={card.rarity.toLowerCase()}
      data-owned={isOwned}
      style={{ "--rarity-color": rarityMeta[card.rarity].color } as CSSProperties}
    >
      <div className="sea-card__topline">
        <span>SK · {String(card.number).padStart(2, "0")}</span>
        <span>{region.englishName.slice(0, 3)}</span>
      </div>
      <CardArtwork card={card} locked={!isOwned} photo={isOwned ? photo : undefined} />
      <div className="sea-card__body">
        <div className="sea-card__title-row">
          <h3>{isOwned ? card.name : "미발견 카드"}</h3>
          {owned > 1 && <span className="copy-count">×{owned}</span>}
        </div>
        <div className="sea-card__footer">
          <span>{isOwned ? region.name : "탐험으로 발견"}</span>
          <RarityBadge rarity={card.rarity} />
        </div>
      </div>
      {!isOwned && (
        <div className="sea-card__lock" aria-hidden="true">
          <span>미발견</span>
        </div>
      )}
      {photo && isOwned && <span className="photo-record-badge">내 사진</span>}
    </article>
  );

  if (!onClick) return content;

  return (
    <button
      type="button"
      className="card-button"
      onClick={onClick}
      aria-label={label ?? `${isOwned ? card.name : "미발견 카드"} 상세 보기`}
    >
      {content}
    </button>
  );
}

export function MiniCard({
  card,
  owned = true,
  photo,
}: {
  card: SeaCard;
  owned?: boolean;
  photo?: string;
}) {
  return (
    <div
      className="mini-card"
      data-rarity={card.rarity.toLowerCase()}
      style={
        {
          "--mini-a": card.visual.gradient[0],
          "--mini-b": card.visual.gradient[1],
          "--mini-c": card.visual.gradient[2],
          "--rarity-color": rarityMeta[card.rarity].color,
        } as CSSProperties
      }
    >
      {photo && owned && (
        // eslint-disable-next-line @next/next/no-img-element
        <img className="mini-card__photo" src={photo} alt="" />
      )}
      <span className="mini-card__glyph" aria-hidden="true">
        {owned && !photo ? card.visual.glyph : owned ? "" : "?"}
      </span>
      <span className="mini-card__name">{owned ? card.name : "미발견"}</span>
      <span className="mini-card__rarity">{rarityMeta[card.rarity].label}</span>
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  eyebrow,
  children,
  className = "",
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow?: string;
  children: ReactNode;
  className?: string;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const sheetRef = useRef<HTMLElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    previousFocusRef.current =
      document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const timer = window.setTimeout(() => closeRef.current?.focus(), 30);
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        onClose();
        return;
      }
      if (event.key !== "Tab" || !sheetRef.current) return;
      const focusable = [...sheetRef.current.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])',
      )].filter((element) => !element.hasAttribute("hidden"));
      if (focusable.length === 0) {
        event.preventDefault();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => {
      window.clearTimeout(timer);
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKey);
      previousFocusRef.current?.focus();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div className="modal-backdrop">
      <button
        type="button"
        className="modal-backdrop__dismiss"
        onClick={onClose}
        aria-label="모달 닫기"
        tabIndex={-1}
      />
      <section
        ref={sheetRef}
        className={`modal-sheet ${className}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
      >
        <div className="modal-sheet__handle" aria-hidden="true" />
        <header className="modal-sheet__header">
          <div>
            {eyebrow && <p className="eyebrow">{eyebrow}</p>}
            <h2 id="modal-title">{title}</h2>
          </div>
          <button ref={closeRef} type="button" className="icon-button" onClick={onClose} aria-label="닫기">
            ×
          </button>
        </header>
        {children}
      </section>
    </div>
  );
}

export function EmptyState({ glyph, title, description }: { glyph: string; title: string; description: string }) {
  return (
    <div className="empty-state">
      <span aria-hidden="true">{glyph}</span>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  );
}
