"use client";

import { useEffect, useRef, useState } from "react";

export interface Coordinates {
  lat: number;
  lng: number;
}

export type GeoSource = "gps" | "demo";

export interface GeoState {
  status: "idle" | "loading" | "ready" | "denied" | "unavailable";
  coords?: Coordinates;
  source?: GeoSource;
  message?: string;
  updatedAt?: number;
}

export interface AcquisitionRule {
  radiusMeters?: number;
  /** 0~24 사이의 24시간제 시작 시각입니다. */
  startHour?: number;
  /** 0~24 사이의 24시간제 종료 시각입니다. */
  endHour?: number;
  timeWindow?: {
    startHour?: number;
    endHour?: number;
    start?: number;
    end?: number;
  };
}

export interface LocatedSpot {
  regionId: string;
  coordinates?: Coordinates;
  coords?: Coordinates;
  coordinate?: Coordinates;
  lat?: number;
  lng?: number;
  latitude?: number;
  longitude?: number;
}

export interface AcquisitionEvaluation {
  eligible: boolean;
  distance: number | null;
  distanceOk: boolean;
  timeOk: boolean;
  reasons: string[];
  /** 시간 조건 판정에 사용된 24시간제 시각입니다. */
  effectiveHour: number;
}

const EARTH_RADIUS_METERS = 6_371_000;
const DEFAULT_RADIUS_METERS = 300;
const DEMO_HOUR = 18;
const KAKAO_SCRIPT_ID = "sea-k-kakao-map-sdk";
const KAKAO_MISSING_KEY_MESSAGE =
  "카카오맵 API 키를 설정하면 지도를 사용할 수 있습니다";

function toRadians(value: number) {
  return (value * Math.PI) / 180;
}

function isCoordinates(value: unknown): value is Coordinates {
  if (!value || typeof value !== "object") return false;
  const candidate = value as Partial<Coordinates>;
  return Number.isFinite(candidate.lat) && Number.isFinite(candidate.lng);
}

function coordinatesOf(spot: LocatedSpot): Coordinates | null {
  const nested = spot.coordinates ?? spot.coords ?? spot.coordinate;
  if (isCoordinates(nested)) return nested;

  const lat = spot.lat ?? spot.latitude;
  const lng = spot.lng ?? spot.longitude;
  return Number.isFinite(lat) && Number.isFinite(lng)
    ? { lat: lat as number, lng: lng as number }
    : null;
}

/** 두 좌표 사이의 직선거리를 Haversine 공식으로 계산합니다. */
export function distanceMeters(a: Coordinates, b: Coordinates): number {
  const latitudeDelta = toRadians(b.lat - a.lat);
  const longitudeDelta = toRadians(b.lng - a.lng);
  const latitudeA = toRadians(a.lat);
  const latitudeB = toRadians(b.lat);

  const haversine =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos(latitudeA) *
      Math.cos(latitudeB) *
      Math.sin(longitudeDelta / 2) ** 2;

  return (
    EARTH_RADIUS_METERS *
    2 *
    Math.atan2(Math.sqrt(haversine), Math.sqrt(1 - haversine))
  );
}

export function formatDistance(distance: number | null | undefined): string {
  if (distance == null || !Number.isFinite(distance)) return "위치 확인 필요";
  const safeDistance = Math.max(0, distance);
  if (safeDistance < 1_000) return `${Math.round(safeDistance)}m`;
  const kilometers = safeDistance / 1_000;
  return `${kilometers < 10 ? kilometers.toFixed(1) : Math.round(kilometers)}km`;
}

export function nearestRegionId<T extends LocatedSpot>(
  coords: Coordinates,
  spots: readonly T[],
): T["regionId"] | null {
  let nearest: T | null = null;
  let nearestDistance = Number.POSITIVE_INFINITY;

  for (const spot of spots) {
    const spotCoords = coordinatesOf(spot);
    if (!spotCoords) continue;
    const distance = distanceMeters(coords, spotCoords);
    if (distance < nearestDistance) {
      nearest = spot;
      nearestDistance = distance;
    }
  }

  return nearest?.regionId ?? null;
}

function hourIsInsideRange(hour: number, start: number, end: number) {
  if (start === end) return true;
  if (start < end) return hour >= start && hour <= end;
  // 자정을 넘기는 범위(예: 20시~02시)도 지원합니다.
  return hour >= start || hour <= end;
}

function displayHour(hour: number) {
  const normalized = ((hour % 24) + 24) % 24;
  const wholeHour = Math.floor(normalized);
  const minutes = Math.round((normalized - wholeHour) * 60);
  return minutes > 0
    ? `${String(wholeHour).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`
    : `${String(wholeHour).padStart(2, "0")}:00`;
}

export function evaluateAcquisition(
  rule: AcquisitionRule,
  spot: LocatedSpot,
  geoState: GeoState,
  now?: Date,
): AcquisitionEvaluation {
  const reasons: string[] = [];
  const spotCoords = coordinatesOf(spot);
  const radius = Math.max(0, rule.radiusMeters ?? DEFAULT_RADIUS_METERS);
  const usingDefaultDemoTime = geoState.source === "demo" && now === undefined;
  const clock = now ?? new Date();
  const effectiveHour = usingDefaultDemoTime
    ? DEMO_HOUR
    : clock.getHours() + clock.getMinutes() / 60;

  let distance: number | null = null;
  let distanceOk = false;

  if (geoState.status !== "ready" || !geoState.coords) {
    if (geoState.status === "denied") {
      reasons.push("위치 권한이 없어 정확한 현장 인증을 할 수 없습니다.");
    } else if (geoState.status === "loading") {
      reasons.push("현재 위치를 확인하고 있습니다.");
    } else {
      reasons.push("현재 위치를 확인해야 촬영 인증을 진행할 수 있습니다.");
    }
  } else if (!spotCoords) {
    reasons.push("이 장소의 좌표 정보가 아직 등록되지 않았습니다.");
  } else {
    distance = distanceMeters(geoState.coords, spotCoords);
    distanceOk = distance <= radius;
    if (!distanceOk) {
      reasons.push(
        `획득 장소 반경 ${Math.round(radius)}m 안으로 이동해 주세요. 현재 거리 ${formatDistance(distance)}입니다.`,
      );
    }
  }

  const startHour =
    rule.startHour ?? rule.timeWindow?.startHour ?? rule.timeWindow?.start;
  const endHour =
    rule.endHour ?? rule.timeWindow?.endHour ?? rule.timeWindow?.end;
  const hasTimeRule = Number.isFinite(startHour) && Number.isFinite(endHour);
  const timeOk = hasTimeRule
    ? hourIsInsideRange(effectiveHour, startHour as number, endHour as number)
    : true;

  if (!timeOk) {
    reasons.push(
      `촬영 가능 시간은 ${displayHour(startHour as number)}~${displayHour(endHour as number)}입니다.`,
    );
  }
  if (usingDefaultDemoTime && hasTimeRule) {
    reasons.push(
      "데모 위치에서는 발표 시연을 위해 오후 6시 기준으로 시간 조건을 확인합니다.",
    );
  }

  return {
    eligible: distanceOk && timeOk,
    distance,
    distanceOk,
    timeOk,
    reasons,
    effectiveHour,
  };
}

function readAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      typeof reader.result === "string"
        ? resolve(reader.result)
        : reject(new Error("사진을 읽을 수 없습니다."));
    reader.onerror = () => reject(new Error("사진을 읽는 중 오류가 발생했습니다."));
    reader.readAsDataURL(file);
  });
}

function loadImage(source: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("선택한 사진을 처리할 수 없습니다."));
    image.src = source;
  });
}

function dataUrlBytes(dataUrl: string) {
  const commaIndex = dataUrl.indexOf(",");
  if (commaIndex < 0) return dataUrl.length;
  const payload = dataUrl.slice(commaIndex + 1);
  return Math.ceil((payload.length * 3) / 4);
}

/** localStorage 보관을 위해 사진을 작은 JPEG 미리보기로 압축합니다. */
export async function compressPhoto(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("이미지 파일만 촬영하거나 선택할 수 있습니다.");
  }
  if (file.size === 0) {
    throw new Error("비어 있는 사진 파일은 사용할 수 없습니다.");
  }
  if (typeof document === "undefined") {
    throw new Error("이 브라우저에서는 사진을 처리할 수 없습니다.");
  }

  const image = await loadImage(await readAsDataUrl(file));
  if (!image.naturalWidth || !image.naturalHeight) {
    throw new Error("사진의 크기를 확인할 수 없습니다.");
  }

  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  if (!context) throw new Error("이 브라우저에서는 사진을 압축할 수 없습니다.");

  const maxEdge = 720;
  const initialScale = Math.min(
    1,
    maxEdge / Math.max(image.naturalWidth, image.naturalHeight),
  );
  let width = Math.max(1, Math.round(image.naturalWidth * initialScale));
  let height = Math.max(1, Math.round(image.naturalHeight * initialScale));
  let quality = 0.84;
  const targetBytes = 110 * 1024;
  let result = "";

  // 품질을 먼저 낮추고, 그래도 큰 사진은 해상도를 조금씩 줄입니다.
  for (let attempt = 0; attempt < 12; attempt += 1) {
    canvas.width = width;
    canvas.height = height;
    context.fillStyle = "#071b2d";
    context.fillRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);
    result = canvas.toDataURL("image/jpeg", quality);

    if (result === "data:," || !result.startsWith("data:image/jpeg")) {
      throw new Error("사진을 JPEG 형식으로 변환할 수 없습니다.");
    }
    if (dataUrlBytes(result) <= targetBytes) break;

    if (quality > 0.46) {
      quality = Math.max(0.44, quality - 0.08);
    } else {
      width = Math.max(240, Math.round(width * 0.84));
      height = Math.max(240, Math.round(height * 0.84));
    }
  }

  return result;
}

type KakaoLatLngValue = object;

interface KakaoMapValue {
  setBounds(bounds: KakaoBoundsValue): void;
}

interface KakaoBoundsValue {
  extend(position: KakaoLatLngValue): void;
}

interface KakaoMarkerValue {
  setMap(map: KakaoMapValue | null): void;
}

interface KakaoMapsApi {
  load(callback: () => void): void;
  LatLng: new (lat: number, lng: number) => KakaoLatLngValue;
  LatLngBounds: new () => KakaoBoundsValue;
  Map: new (
    container: HTMLElement,
    options: { center: KakaoLatLngValue; level: number },
  ) => KakaoMapValue;
  Marker: new (options: {
    map: KakaoMapValue;
    position: KakaoLatLngValue;
    title?: string;
  }) => KakaoMarkerValue;
}

interface KakaoNamespace {
  maps: KakaoMapsApi;
}

declare global {
  interface Window {
    SEA_K_CONFIG?: { kakaoJavascriptKey?: string };
    kakao?: KakaoNamespace;
  }
}

let kakaoLoader: Promise<KakaoNamespace> | null = null;
let kakaoLoaderKey = "";

function loadKakaoMaps(key: string): Promise<KakaoNamespace> {
  if (window.kakao?.maps) {
    return new Promise((resolve) => {
      window.kakao?.maps.load(() => resolve(window.kakao as KakaoNamespace));
    });
  }
  if (kakaoLoader && kakaoLoaderKey === key) return kakaoLoader;

  kakaoLoaderKey = key;
  kakaoLoader = new Promise((resolve, reject) => {
    const finish = () => {
      if (!window.kakao?.maps) {
        reject(new Error("카카오맵을 불러오지 못했습니다."));
        return;
      }
      window.kakao.maps.load(() => resolve(window.kakao as KakaoNamespace));
    };

    const existing = document.getElementById(KAKAO_SCRIPT_ID) as
      | HTMLScriptElement
      | null;
    if (existing) {
      existing.addEventListener("load", finish, { once: true });
      existing.addEventListener(
        "error",
        () => reject(new Error("카카오맵을 불러오지 못했습니다.")),
        { once: true },
      );
      return;
    }

    const script = document.createElement("script");
    script.id = KAKAO_SCRIPT_ID;
    script.async = true;
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${encodeURIComponent(key)}&autoload=false`;
    script.addEventListener("load", finish, { once: true });
    script.addEventListener(
      "error",
      () => reject(new Error("카카오맵을 불러오지 못했습니다.")),
      { once: true },
    );
    document.head.appendChild(script);
  });

  return kakaoLoader;
}

export interface KakaoMapProps {
  center: Coordinates;
  target: Coordinates;
  user?: Coordinates;
  height?: number | string;
}

export function KakaoMap({
  center,
  target,
  user,
  height = 240,
}: KakaoMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "fallback">(
    "loading",
  );
  const userLat = user?.lat;
  const userLng = user?.lng;

  useEffect(() => {
    let active = true;
    const markers: KakaoMarkerValue[] = [];
    const key = window.SEA_K_CONFIG?.kakaoJavascriptKey?.trim();

    if (!key) {
      // 외부 설정 확인 결과를 다음 마이크로태스크에서 반영해 effect의 동기 상태 갱신을 피합니다.
      Promise.resolve().then(() => {
        if (active) setStatus("fallback");
      });
      return () => {
        active = false;
      };
    }

    loadKakaoMaps(key)
      .then((kakao) => {
        if (!active || !containerRef.current) return;
        const mapCenter = new kakao.maps.LatLng(center.lat, center.lng);
        const targetPosition = new kakao.maps.LatLng(target.lat, target.lng);
        const map = new kakao.maps.Map(containerRef.current, {
          center: mapCenter,
          level: 4,
        });
        markers.push(
          new kakao.maps.Marker({
            map,
            position: targetPosition,
            title: "카드 획득 장소",
          }),
        );

        if (userLat != null && userLng != null) {
          const userPosition = new kakao.maps.LatLng(userLat, userLng);
          markers.push(
            new kakao.maps.Marker({
              map,
              position: userPosition,
              title: "현재 위치",
            }),
          );
          const bounds = new kakao.maps.LatLngBounds();
          bounds.extend(targetPosition);
          bounds.extend(userPosition);
          map.setBounds(bounds);
        }
        setStatus("ready");
      })
      .catch(() => {
        if (active) setStatus("fallback");
      });

    return () => {
      active = false;
      markers.forEach((marker) => marker.setMap(null));
    };
  }, [center.lat, center.lng, target.lat, target.lng, userLat, userLng]);

  const resolvedHeight = typeof height === "number" ? `${height}px` : height;
  const fallback = status === "fallback";

  return (
    <div
      aria-label="카드 획득 장소 지도"
      style={{
        position: "relative",
        height: resolvedHeight,
        minHeight: 180,
        overflow: "hidden",
        border: "1px solid rgba(99, 224, 215, 0.24)",
        borderRadius: 18,
        background:
          "radial-gradient(circle at 72% 24%, rgba(76, 220, 209, .2), transparent 32%), linear-gradient(145deg, #0b4260, #071b33 62%, #101b42)",
      }}
    >
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />
      {status === "loading" && (
        <div style={fallbackPanelStyle} role="status">
          지도를 불러오고 있습니다…
        </div>
      )}
      {fallback && (
        <div style={fallbackPanelStyle} role="status">
          <span aria-hidden="true" style={{ fontSize: 28 }}>
            ≋
          </span>
          <strong style={{ fontSize: 14, lineHeight: 1.5 }}>
            {KAKAO_MISSING_KEY_MESSAGE}
          </strong>
          <span style={{ color: "rgba(224, 249, 255, .7)", fontSize: 12 }}>
            장소 좌표와 길찾기 링크는 계속 이용할 수 있습니다.
          </span>
        </div>
      )}
    </div>
  );
}

const fallbackPanelStyle = {
  position: "absolute",
  inset: 0,
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  gap: 8,
  padding: 24,
  color: "#e8ffff",
  textAlign: "center",
  background:
    "repeating-radial-gradient(ellipse at 50% 120%, transparent 0 22px, rgba(85, 224, 214, .08) 24px 27px, transparent 29px 44px)",
  backdropFilter: "blur(2px)",
} as const;
