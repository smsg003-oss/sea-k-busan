"use client";

import {
  useCallback,
  useMemo,
  useRef,
  useState,
  useEffect,
  type ChangeEvent,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  acquisitionByCardId,
  cardById,
  cardPacks,
  cards,
  decorItems,
  explorationSpots,
  regionRewards,
  regions,
  regionById,
  spotById,
  tradeListings,
  type DecorItem,
  type RegionId,
  type RegionReward,
  type SeaCard,
} from "./data";
import {
  Brand,
  Coin,
  EmptyState,
  MiniCard,
  Modal,
  RarityBadge,
  SeaCardTile,
} from "./components";
import {
  KakaoMap,
  compressPhoto,
  evaluateAcquisition,
  formatDistance,
  nearestRegionId,
  type GeoState,
} from "./location";
import {
  DEFAULT_PROGRESS,
  STORAGE_KEY,
  buyOrEquipDecor,
  buyPack,
  captureCard,
  completeTrade,
  getLocalDateKey,
  markOnboardingSeen,
  redeemRegionReward,
  safeParseProgress,
  type ProgressState,
} from "./progress";

type Screen = "home" | "explore" | "album" | "shop" | "market";
type ShopTab = "packs" | "decor" | "rewards" | "wallet";

const onboardingSteps = [
  { eyebrow: "SEA:K 시작 안내", title: "SEA:K에 오신 것을 환영합니다", description: "부산 바다를 탐험하고, 사진으로 인증해 나만의 디지털 카드를 수집해보세요.", glyph: "◌" },
  { eyebrow: "01 · 주변 카드 찾기", title: "위치로 가까운 카드를 찾아요", description: "위치 권한을 허용하면 지금 주변에서 얻을 수 있는 카드를 안내합니다. 권한을 거부해도 데모 위치 선택으로 체험할 수 있어요.", glyph: "⌖" },
  { eyebrow: "02 · 현장 인증", title: "조건을 확인하고 사진을 남겨요", description: "카드를 선택해 획득 조건을 확인한 뒤, 현장에서 사진을 촬영하면 카드와 코인을 얻을 수 있습니다.", glyph: "◈" },
  { eyebrow: "03 · 수집과 보상", title: "기록을 모아 더 멀리 탐험해요", description: "모은 카드는 앨범에서 확인하고, 코인은 카드팩·꾸미기·지역 보상에 사용할 수 있습니다.", glyph: "✦" },
  { eyebrow: "준비 완료", title: "이제 부산 바다를 발견해볼까요?", description: "가까운 카드부터 살펴보고, 나만의 바다 기록을 시작해보세요.", glyph: "≈" },
] as const;

const navItems: Array<{ id: Screen; label: string; glyph: string }> = [
  { id: "home", label: "홈", glyph: "⌂" },
  { id: "explore", label: "지도", glyph: "⌖" },
  { id: "album", label: "앨범", glyph: "▣" },
  { id: "shop", label: "상점", glyph: "▱" },
  { id: "market", label: "교환", glyph: "⇄" },
];

const validScreens = new Set<Screen>(navItems.map((item) => item.id));

function screenFromHash(): Screen {
  if (typeof window === "undefined") return "home";
  const value = window.location.hash.replace(/^#\/?/, "") as Screen;
  return validScreens.has(value) ? value : "home";
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("ko-KR").format(value);
}

function uniqueCardCount(progress: ProgressState) {
  return cards.filter((card) => (progress.cards[card.id] ?? 0) > 0).length;
}

function totalCardCount(progress: ProgressState) {
  return Object.values(progress.cards).reduce((sum, count) => sum + count, 0);
}

function duplicateCardCount(progress: ProgressState) {
  return Object.values(progress.cards).reduce(
    (sum, count) => sum + Math.max(0, count - 1),
    0,
  );
}

function applyDailyLimit(
  progress: ProgressState,
  card: SeaCard,
  spotId: string,
  evaluation: ReturnType<typeof evaluateAcquisition>,
) {
  const dailyBlocked =
    progress.verifications[spotId] === getLocalDateKey();

  if (!dailyBlocked) return evaluation;
  return {
    ...evaluation,
    eligible: false,
    reasons: [
      "오늘은 이미 이 장소에서 카드를 획득했어요. 내일 다시 탐험해 주세요.",
      ...evaluation.reasons,
    ],
  };
}

function cardsByDistance(geo: GeoState, progress: ProgressState) {
  return cards
    .map((card) => {
      const rule = acquisitionByCardId[card.id];
      const spot = spotById[rule.spotId];
      const evaluation = applyDailyLimit(
        progress,
        card,
        spot.id,
        evaluateAcquisition(rule, spot, geo),
      );
      return { card, rule, spot, evaluation };
    })
    .sort((a, b) => {
      if (a.evaluation.eligible !== b.evaluation.eligible) {
        return a.evaluation.eligible ? -1 : 1;
      }
      return (a.evaluation.distance ?? Number.MAX_VALUE) -
        (b.evaluation.distance ?? Number.MAX_VALUE);
    });
}

function readDeviceLocation(): Promise<GeoState> {
  if (!("geolocation" in navigator)) {
    return Promise.resolve({
      status: "unavailable",
      message: "이 기기에서는 현재 위치를 확인할 수 없습니다. 데모 위치를 이용해 주세요.",
    });
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          status: "ready",
          source: "gps",
          coords: {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          },
          updatedAt: Date.now(),
          message: "현재 위치를 확인했습니다.",
        });
      },
      (error) => {
        const denied = error.code === error.PERMISSION_DENIED;
        resolve({
          status: denied ? "denied" : "unavailable",
          message: denied
            ? "위치 권한이 거부되어 정확한 현장 인증이 불가능합니다. 데모 위치로 흐름을 체험할 수 있어요."
            : "현재 위치를 가져오지 못했습니다. 잠시 뒤 다시 시도하거나 데모 위치를 이용해 주세요.",
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
    );
  });
}

export function SeaKApp() {
  const [progress, setProgress] = useState<ProgressState>(DEFAULT_PROGRESS);
  const progressRef = useRef<ProgressState>(DEFAULT_PROGRESS);
  const [hydrated, setHydrated] = useState(false);
  const [screen, setScreenState] = useState<Screen>("home");
  const [geo, setGeo] = useState<GeoState>({ status: "idle" });
  const [toast, setToast] = useState("");
  const [coinPulse, setCoinPulse] = useState(false);
  const [selectedCard, setSelectedCard] = useState<SeaCard | null>(null);
  const [reveal, setReveal] = useState<{
    card: SeaCard;
    coins: number;
    source: "촬영" | "카드팩" | "교환";
    title: string;
  } | null>(null);
  const [packStage, setPackStage] = useState<"opening" | "revealed">("revealed");
  const [onboardingStep, setOnboardingStep] = useState<number | null>(null);

  useEffect(() => {
    const syncHash = () => setScreenState(screenFromHash());
    window.addEventListener("hashchange", syncHash);
    const timer = window.setTimeout(() => {
      setScreenState(screenFromHash());
      const storedProgress = safeParseProgress(window.localStorage.getItem(STORAGE_KEY));
      progressRef.current = storedProgress;
      setProgress(storedProgress);
      if (!storedProgress.onboardingSeen) setOnboardingStep(0);
      setHydrated(true);
    }, 0);
    return () => {
      window.clearTimeout(timer);
      window.removeEventListener("hashchange", syncHash);
    };
  }, []);

  const commitProgress = useCallback((nextProgress: ProgressState) => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(nextProgress));
      progressRef.current = nextProgress;
      setProgress(nextProgress);
      return true;
    } catch {
      setToast("브라우저 저장 공간이 부족해 변경하지 못했어요. 기존 사진을 줄이거나 교체해 주세요.");
      return false;
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 3200);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (!coinPulse) return;
    const timer = window.setTimeout(() => setCoinPulse(false), 420);
    return () => window.clearTimeout(timer);
  }, [coinPulse]);

  useEffect(() => {
    if (!reveal || reveal.source !== "카드팩" || packStage !== "opening") return;
    const timer = window.setTimeout(() => setPackStage("revealed"), 850);
    return () => window.clearTimeout(timer);
  }, [packStage, reveal]);

  const setScreen = useCallback((next: Screen) => {
    setScreenState(next);
    window.location.hash = `/${next}`;
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const notify = useCallback((message: string) => setToast(message), []);

  const requestLocation = useCallback(async () => {
    setGeo({ status: "loading", message: "현재 위치를 확인하고 있어요." });
    setGeo(await readDeviceLocation());
  }, []);

  const setDemoRegion = useCallback((regionId: RegionId) => {
    const spot = explorationSpots.find((item) => item.regionId === regionId);
    if (!spot) return;
    setGeo({
      status: "ready",
      source: "demo",
      coords: spot.coordinates,
      updatedAt: Date.now(),
      message: `${regionById[regionId].name} 데모 위치 · 시간 조건은 오후 6시 기준`,
    });
  }, []);

  const handleBuyPack = useCallback(
    (packId: string) => {
      const pack = cardPacks.find((item) => item.id === packId);
      if (!pack) return;
      const result = buyPack(progress, pack);
      if (!result.ok) return notify(result.reason);
      if (!commitProgress(result.state)) return;
      setPackStage("opening");
      setReveal({
        card: result.card,
        coins: 0,
        source: "카드팩",
        title: `${pack.name} 개봉`,
      });
    },
    [commitProgress, notify, progress],
  );

  const handleDecor = useCallback(
    (item: DecorItem) => {
      const result = buyOrEquipDecor(progress, item);
      if (!result.ok) return notify(result.reason);
      if (!commitProgress(result.state)) return;
      notify(
        result.action === "purchased"
          ? `${item.name}을 구매하고 적용했어요.`
          : `${item.name}을 적용했어요.`,
      );
    },
    [commitProgress, notify, progress],
  );

  const handleReward = useCallback(
    (reward: RegionReward) => {
      const result = redeemRegionReward(progress, reward);
      if (!result.ok) return notify(result.reason);
      if (!commitProgress(result.state)) return;
      setCoinPulse(true);
      notify(`${reward.name} 교환 완료! 내 보상함에 담았어요.`);
    },
    [commitProgress, notify, progress],
  );

  const handleTrade = useCallback(
    (listingId: string) => {
      const listing = tradeListings.find((item) => item.id === listingId);
      if (!listing) return;
      const result = completeTrade(progress, listing);
      if (!result.ok) return notify(result.reason);
      if (!commitProgress(result.state)) return;
      if (result.coins > 0) setCoinPulse(true);
      setReveal({
        card: result.receivedCard,
        coins: result.coins,
        source: "교환",
        title: `${listing.trader.name}님과 교환 완료!`,
      });
    },
    [commitProgress, notify, progress],
  );

  const handleCapture = useCallback(
    async (card: SeaCard, file: File) => {
      try {
        const rule = acquisitionByCardId[card.id];
        const spot = spotById[rule.spotId];
        let captureGeo = geo;

        if (geo.source === "gps") {
          captureGeo = await readDeviceLocation();
          setGeo(captureGeo);
          if (captureGeo.status !== "ready") {
            notify(captureGeo.message ?? "촬영 시점의 위치를 다시 확인하지 못했습니다.");
            return false;
          }
        }

        const latestProgress = progressRef.current;
        const latestEvaluation = applyDailyLimit(
          latestProgress,
          card,
          spot.id,
          evaluateAcquisition(rule, spot, captureGeo),
        );
        if (!latestEvaluation.eligible) {
          notify(latestEvaluation.reasons[0] ?? "현재 위치와 시간 조건을 다시 확인해 주세요.");
          return false;
        }

        const photo = await compressPhoto(file);
        const result = captureCard(
          latestProgress,
          card,
          photo,
          rule.coinReward,
          new Date(),
          spot.id,
        );
        if (!result.ok) {
          notify(result.reason);
          return false;
        }
        if (!commitProgress(result.state)) return false;
        setSelectedCard(null);
        if (result.coins > 0) setCoinPulse(true);
        setReveal({
          card,
          coins: result.coins,
          source: "촬영",
          title: result.isFirstCapture ? "현장 발견 완료!" : "대표 사진을 바꿨어요!",
        });
        return true;
      } catch (error) {
        notify(error instanceof Error ? error.message : "사진을 처리하지 못했습니다.");
        return false;
      }
    },
    [commitProgress, geo, notify],
  );

  const closeReveal = useCallback(() => {
    setReveal(null);
    setPackStage("revealed");
  }, []);
  const closeCard = useCallback(() => setSelectedCard(null), []);
  const finishOnboarding = useCallback(
    (startExploring = false) => {
      commitProgress(markOnboardingSeen(progressRef.current));
      setOnboardingStep(null);
      if (startExploring) setScreen("explore");
    },
    [commitProgress, setScreen],
  );

  const currentRegionId =
    geo.status === "ready" && geo.coords
      ? (nearestRegionId(geo.coords, explorationSpots) as RegionId | null)
      : null;

  let main: ReactNode;
  switch (screen) {
    case "explore":
      main = (
        <ExploreScreen
          key={currentRegionId ?? "all"}
          progress={progress}
          geo={geo}
          currentRegionId={currentRegionId}
          onLocation={requestLocation}
          onDemo={setDemoRegion}
          onCard={setSelectedCard}
        />
      );
      break;
    case "album":
      main = <AlbumScreen progress={progress} onCard={setSelectedCard} />;
      break;
    case "shop":
      main = (
        <ShopScreen
          progress={progress}
          onBuyPack={handleBuyPack}
          onDecor={handleDecor}
          onReward={handleReward}
        />
      );
      break;
    case "market":
      main = <MarketScreen progress={progress} onTrade={handleTrade} />;
      break;
    default:
      main = (
        <HomeScreen
          progress={progress}
          geo={geo}
          currentRegionId={currentRegionId}
          onNavigate={setScreen}
          onLocation={requestLocation}
          onDemo={setDemoRegion}
          onCard={setSelectedCard}
          onDismissOnboarding={() => commitProgress(markOnboardingSeen(progress))}
        />
      );
  }

  return (
    <div
      className={`sea-shell ${hydrated ? "is-hydrated" : ""}`}
      data-album-background={progress.activeBackground ?? undefined}
    >
      <div className="sea-shell__contours" aria-hidden="true" />
      <header className="topbar topbar--simple">
        <button
          type="button"
          className="brand-button"
          onClick={() => setScreen("home")}
          aria-label="SEA:K 홈"
        >
          <Brand compact />
        </button>
        <nav className="desktop-nav" aria-label="주요 메뉴">
          {navItems.map((item) => (
            <button
              type="button"
              key={item.id}
              className="desktop-nav__item"
              aria-current={screen === item.id ? "page" : undefined}
              onClick={() => setScreen(item.id)}
            >
              <span aria-hidden="true">{item.glyph}</span>
              {item.label}
            </button>
          ))}
        </nav>
        <div className="topbar__stats">
          <span className="topbar__cards" aria-label={`보유 카드 ${uniqueCardCount(progress)}종`}>
            <i aria-hidden="true">▣</i>
            <strong>{uniqueCardCount(progress)}</strong>
          </span>
          <span
            className={`coin-balance ${coinPulse ? "is-bumped" : ""}`}
            aria-label={`보유 코인 ${progress.coins}`}
          >
            <Coin />
            <strong>{formatNumber(progress.coins)}</strong>
          </span>
        </div>
      </header>

      <main className="app-main">{main}</main>

      <nav className="bottom-nav" aria-label="주요 메뉴">
        {navItems.map((item) => (
          <button
            type="button"
            key={item.id}
            className="bottom-nav__item"
            aria-current={screen === item.id ? "page" : undefined}
            onClick={() => setScreen(item.id)}
          >
            <span className="bottom-nav__glyph" aria-hidden="true">
              {item.glyph}
            </span>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="sr-live" role="status" aria-live="polite" aria-atomic="true">
        {toast}
      </div>
      {toast && <div className="toast">{toast}</div>}

      <CardDetailModal
        key={selectedCard?.id ?? "closed"}
        card={selectedCard}
        progress={progress}
        geo={geo}
        onClose={closeCard}
        onCapture={handleCapture}
        onLocation={requestLocation}
      />
      <RevealModal
        reveal={reveal}
        packStage={packStage}
        progress={progress}
        onClose={closeReveal}
        onAlbum={() => {
          closeReveal();
          setScreen("album");
        }}
      />
      {hydrated && onboardingStep !== null && (
        <OnboardingModal
          step={onboardingStep}
          onNext={() => setOnboardingStep((value) => Math.min((value ?? 0) + 1, onboardingSteps.length - 1))}
          onBack={() => setOnboardingStep((value) => Math.max((value ?? 0) - 1, 0))}
          onSkip={() => finishOnboarding(false)}
          onStart={() => finishOnboarding(true)}
        />
      )}
    </div>
  );
}

function OnboardingModal({
  step,
  onNext,
  onBack,
  onSkip,
  onStart,
}: {
  step: number;
  onNext: () => void;
  onBack: () => void;
  onSkip: () => void;
  onStart: () => void;
}) {
  const current = onboardingSteps[step];
  const isLast = step === onboardingSteps.length - 1;

  return (
    <section className="onboarding-modal" role="dialog" aria-modal="true" aria-labelledby="onboarding-title">
      <div className="onboarding-modal__wave" aria-hidden="true" />
      <div className="onboarding-modal__panel">
        <button type="button" className="onboarding-modal__skip" onClick={onSkip}>건너뛰기</button>
        <div className="onboarding-modal__mark" aria-hidden="true">{current.glyph}</div>
        <p className="eyebrow">{current.eyebrow}</p>
        <h2 id="onboarding-title">{current.title}</h2>
        <p className="onboarding-modal__description">{current.description}</p>
        <div className="onboarding-modal__progress" aria-label={`${step + 1} / ${onboardingSteps.length} 단계`}>
          {onboardingSteps.map((item, index) => <i key={item.title} className={index === step ? "is-current" : index < step ? "is-complete" : ""} />)}
        </div>
        <span className="onboarding-modal__count">{step + 1} / {onboardingSteps.length}</span>
        <div className="onboarding-modal__actions">
          {step > 0 && !isLast && <button type="button" className="button button--soft" onClick={onBack}>이전</button>}
          <button type="button" className="button button--primary" onClick={isLast ? onStart : onNext}>{isLast ? "탐험 시작하기" : "다음"}</button>
        </div>
      </div>
    </section>
  );
}

function LocationControls({
  geo,
  onLocation,
  onDemo,
  compact = false,
}: {
  geo: GeoState;
  onLocation: () => void;
  onDemo: (regionId: RegionId) => void;
  compact?: boolean;
}) {
  const selectedDemoRegion =
    geo.status === "ready" && geo.source === "demo" && geo.coords
      ? nearestRegionId(geo.coords, explorationSpots) ?? ""
      : "";

  return (
    <div className={`location-controls ${compact ? "location-controls--compact" : ""}`}>
      <div className="location-status" data-status={geo.status}>
        <span className="location-status__signal" aria-hidden="true">⌖</span>
        <div>
          <strong>
            {geo.status === "ready"
              ? geo.source === "demo"
                ? "데모 위치 사용 중"
                : "현재 위치 확인 완료"
              : geo.status === "loading"
                ? "위치를 확인하는 중"
                : "현재 위치가 필요해요"}
          </strong>
          <small>
            {geo.message ?? "위치 권한을 허용하면 주변에서 획득 가능한 카드를 안내합니다."}
          </small>
        </div>
      </div>
      <div className="location-actions">
        <button
          type="button"
          className="button button--soft"
          onClick={onLocation}
          disabled={geo.status === "loading"}
        >
          {geo.status === "loading" ? "확인 중…" : "내 위치 확인"}
        </button>
        <label className="demo-select">
          <span>데모 위치 선택</span>
          <select
            value={selectedDemoRegion}
            onChange={(event) => {
              if (event.target.value) onDemo(event.target.value as RegionId);
            }}
            aria-label="데모 위치 선택"
          >
            <option value="" disabled>지역 선택</option>
            {regions.map((region) => (
              <option value={region.id} key={region.id}>{region.name}</option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}

function HomeScreen({
  progress,
  geo,
  currentRegionId,
  onNavigate,
  onLocation,
  onDemo,
  onCard,
  onDismissOnboarding,
}: {
  progress: ProgressState;
  geo: GeoState;
  currentRegionId: RegionId | null;
  onNavigate: (screen: Screen) => void;
  onLocation: () => void;
  onDemo: (regionId: RegionId) => void;
  onCard: (card: SeaCard) => void;
  onDismissOnboarding: () => void;
}) {
  const [clockTick, setClockTick] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setClockTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const nearby = useMemo(
    () => {
      void clockTick;
      return cardsByDistance(geo, progress).slice(0, 3);
    },
    [clockTick, geo, progress],
  );
  const currentRegion = currentRegionId ? regionById[currentRegionId] : null;

  return (
    <div className="screen home-focus">
      {!progress.onboardingSeen && (
        <aside className="onboarding-note">
          <span aria-hidden="true">⌖</span>
          <p>
            <strong>위치 권한을 허용하면</strong>
            주변에서 획득 가능한 카드와 남은 거리를 안내합니다.
          </p>
          <button type="button" onClick={onDismissOnboarding} aria-label="안내 닫기">×</button>
        </aside>
      )}

      <section className="nearby-hero glass-panel">
        <div className="nearby-hero__intro">
          <p className="eyebrow">오늘의 바다 탐험</p>
          <Brand />
          <h1>지금 주변에서<br /><em>찾을 수 있는 카드</em></h1>
          <p>
            {currentRegion
              ? `${currentRegion.name} 바다와 가까워요. 조건을 확인하고 나만의 장면을 기록해 보세요.`
              : "현재 위치를 확인하면 가장 가까운 부산 바다 카드부터 보여드려요."}
          </p>
          <div className="current-coast">
            <span className="current-coast__radar" aria-hidden="true"><i />⌖</span>
            <div>
              <small>현재 위치 기반 지역</small>
              <strong>{currentRegion?.name ?? "위치 확인 전"}</strong>
            </div>
          </div>
        </div>

        <div className="nearby-hero__cards">
          {geo.status === "ready" ? (
            nearby.map(({ card, spot, evaluation }) => (
              <button
                type="button"
                className="nearby-card"
                key={card.id}
                onClick={() => onCard(card)}
              >
                <MiniCard
                  card={card}
                  owned={(progress.cards[card.id] ?? 0) > 0}
                  photo={progress.cardPhotos[card.id]}
                />
                <span className={evaluation.eligible ? "nearby-card__ready" : "nearby-card__distance"}>
                  {evaluation.eligible ? "지금 획득 가능" : formatDistance(evaluation.distance)}
                </span>
                <small>{spot.name}</small>
              </button>
            ))
          ) : (
            <div className="location-empty">
              <span aria-hidden="true">◎</span>
              <h2>주변 카드를 찾을 준비가 됐어요</h2>
              <p>GPS를 허용하거나 발표용 데모 위치를 선택해 주세요.</p>
            </div>
          )}
        </div>
      </section>

      <LocationControls geo={geo} onLocation={onLocation} onDemo={onDemo} />

      <button
        type="button"
        className="button button--primary explore-cta"
        onClick={() => onNavigate("explore")}
      >
        <span>탐험 시작하기</span>
        <small>지도에서 카드 조건 확인</small>
        <b aria-hidden="true">→</b>
      </button>

      <section className="home-quick-links" aria-label="빠른 메뉴">
        <button type="button" onClick={() => onNavigate("album")}>
          <span aria-hidden="true">▣</span><strong>카드 앨범</strong><small>내 사진과 수집 기록</small>
        </button>
        <button type="button" onClick={() => onNavigate("shop")}>
          <span aria-hidden="true">▱</span><strong>파도 상점</strong><small>팩·꾸미기·지역 보상</small>
        </button>
        <button type="button" onClick={() => onNavigate("market")}>
          <span aria-hidden="true">⇄</span><strong>교환 장터</strong><small>중복 카드 교환</small>
        </button>
      </section>
    </div>
  );
}

function ScreenIntro({
  eyebrow,
  title,
  description,
  aside,
}: {
  eyebrow: string;
  title: string;
  description: string;
  aside?: ReactNode;
}) {
  return (
    <header className="screen-intro">
      <div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{description}</p></div>
      {aside}
    </header>
  );
}

function ExploreScreen({
  progress,
  geo,
  currentRegionId,
  onLocation,
  onDemo,
  onCard,
}: {
  progress: ProgressState;
  geo: GeoState;
  currentRegionId: RegionId | null;
  onLocation: () => void;
  onDemo: (regionId: RegionId) => void;
  onCard: (card: SeaCard) => void;
}) {
  const [region, setRegion] = useState<RegionId | "all">(currentRegionId ?? "all");
  const [clockTick, setClockTick] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setClockTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, []);
  const ordered = useMemo(() => {
    void clockTick;
    return cardsByDistance(geo, progress);
  }, [clockTick, geo, progress]);
  const visible = ordered.filter(({ card }) => region === "all" || card.regionId === region);
  const mapTarget = visible[0]?.spot;

  return (
    <div className="screen map-screen">
      <ScreenIntro
        eyebrow="부산 바다 탐험 지도"
        title="장소와 조건을 확인해요"
        description="카드를 선택하면 300m 위치 조건과 촬영 시간을 확인할 수 있어요. 사진 등록 전 GPS 확인은 필수입니다."
        aside={
          currentRegionId ? (
            <div className="daily-rule"><span aria-hidden="true">⌖</span><div><strong>{regionById[currentRegionId].name} 인근</strong><small>{geo.source === "demo" ? "데모 위치" : "실제 GPS 위치"}</small></div></div>
          ) : undefined
        }
      />

      <LocationControls geo={geo} onLocation={onLocation} onDemo={onDemo} compact />

      {mapTarget && (
        <div className="explore-map">
          <KakaoMap
            center={geo.coords ?? mapTarget.coordinates}
            target={mapTarget.coordinates}
            user={geo.coords}
            height={260}
          />
          <p>가장 가까운 카드 장소를 기준으로 표시합니다. 카드를 선택하면 상세 위치를 볼 수 있어요.</p>
        </div>
      )}

      <div className="filter-scroller" role="group" aria-label="지역 필터">
        <button type="button" className="filter-pill" aria-pressed={region === "all"} onClick={() => setRegion("all")}>거리순 전체</button>
        {regions.map((item) => (
          <button type="button" key={item.id} className="filter-pill" aria-pressed={region === item.id} onClick={() => setRegion(item.id)}>{item.name}</button>
        ))}
      </div>

      <div className="discovery-grid">
        {visible.map(({ card, rule, spot, evaluation }) => (
          <button
            type="button"
            className="discovery-card glass-panel"
            key={card.id}
            onClick={() => onCard(card)}
          >
            <div className="discovery-card__mini">
              <MiniCard
                card={card}
                owned={(progress.cards[card.id] ?? 0) > 0}
                photo={progress.cardPhotos[card.id]}
              />
            </div>
            <div className="discovery-card__copy">
              <div><RarityBadge rarity={card.rarity} /><span>{regionById[card.regionId].name}</span></div>
              <h2>{card.name}</h2>
              <p><span aria-hidden="true">⌖</span> {spot.name}</p>
              <p className="discovery-card__condition">{rule.conditionText}</p>
              <div className="condition-status" data-ready={evaluation.eligible}>
                <span>{evaluation.eligible ? "✓" : "!"}</span>
                <strong>
                  {evaluation.eligible
                    ? "지금 촬영 가능"
                    : evaluation.reasons[0] ?? "조건 확인 필요"}
                </strong>
              </div>
              <footer><span>{formatDistance(evaluation.distance)}</span><span><Coin size="sm" /> +{rule.coinReward}</span><b>상세 보기 →</b></footer>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function AlbumScreen({ progress, onCard }: { progress: ProgressState; onCard: (card: SeaCard) => void }) {
  const [region, setRegion] = useState<RegionId | "all">("all");
  const [ownedOnly, setOwnedOnly] = useState(false);
  const collected = uniqueCardCount(progress);
  const visibleCards = cards.filter(
    (card) =>
      (region === "all" || card.regionId === region) &&
      (!ownedOnly || (progress.cards[card.id] ?? 0) > 0),
  );

  return (
    <div className="screen album-screen" data-background={progress.activeBackground ?? undefined}>
      <ScreenIntro
        eyebrow="나의 바다 기록"
        title="부산 바다 카드 앨범"
        description="현장에서 촬영한 사진은 카드의 대표 이미지가 되어 이 브라우저에 안전하게 보관됩니다."
        aside={<div className="album-score"><strong>{collected}<small> / {cards.length}</small></strong><span>수집 완료</span></div>}
      />
      <div className="album-progress" aria-label={`도감 완성도 ${Math.round(collected / cards.length * 100)}퍼센트`}>
        <div><span style={{ width: `${collected / cards.length * 100}%` }} /></div>
        <p><strong>{Math.round(collected / cards.length * 100)}%</strong> 완성 · 총 {totalCardCount(progress)}장 · 촬영 기록 {Object.keys(progress.cardPhotos).length}장</p>
      </div>
      <div className="album-toolbar">
        <div className="filter-scroller" role="group" aria-label="카드 지역 필터">
          <button type="button" className="filter-pill" aria-pressed={region === "all"} onClick={() => setRegion("all")}>전체</button>
          {regions.map((item) => <button type="button" key={item.id} className="filter-pill" aria-pressed={region === item.id} onClick={() => setRegion(item.id)}>{item.name}</button>)}
        </div>
        <label className="toggle"><input type="checkbox" checked={ownedOnly} onChange={(event) => setOwnedOnly(event.target.checked)} /><span /><strong>보유만</strong></label>
      </div>
      {visibleCards.length > 0 ? (
        <div className="album-grid album-grid--calm">
          {visibleCards.map((card) => (
            <SeaCardTile
              key={card.id}
              card={card}
              owned={progress.cards[card.id] ?? 0}
              activeFrame={progress.activeFrame}
              photo={progress.cardPhotos[card.id]}
              onClick={() => onCard(card)}
            />
          ))}
        </div>
      ) : <EmptyState glyph="⌁" title="이 조건의 카드가 없어요" description="다른 지역을 선택하거나 보유만 필터를 꺼보세요." />}
    </div>
  );
}

function ShopScreen({
  progress,
  onBuyPack,
  onDecor,
  onReward,
}: {
  progress: ProgressState;
  onBuyPack: (id: string) => void;
  onDecor: (item: DecorItem) => void;
  onReward: (reward: RegionReward) => void;
}) {
  const [tab, setTab] = useState<ShopTab>("packs");
  const ownedRewards = regionRewards.filter((item) => progress.ownedRewards.includes(item.id));
  const shopTabs: Array<[ShopTab, string]> = [
    ["packs", "카드팩"],
    ["decor", "꾸미기"],
    ["rewards", "지역 보상"],
    ["wallet", `내 보상함 ${ownedRewards.length}`],
  ];

  return (
    <div className="screen">
      <ScreenIntro
        eyebrow="탐험 코인 사용처"
        title="파도 상점"
        description="카드팩과 꾸미기 아이템, 부산 바다 지역의 시연용 가상 혜택을 만나보세요."
        aside={<div className="shop-balance"><span>사용 가능 코인</span><strong><Coin /> {formatNumber(progress.coins)}</strong></div>}
      />

      <div className="shop-tabs" role="tablist" aria-label="상점 분류">
        {shopTabs.map(([id, label], index) => (
          <button
            key={id}
            id={`shop-tab-${id}`}
            type="button"
            role="tab"
            aria-selected={tab === id}
            aria-controls={`shop-panel-${id}`}
            tabIndex={tab === id ? 0 : -1}
            onClick={() => setTab(id)}
            onKeyDown={(event) => {
              const offset = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
              if (!offset) return;
              event.preventDefault();
              const nextIndex = (index + offset + shopTabs.length) % shopTabs.length;
              const nextId = shopTabs[nextIndex][0];
              setTab(nextId);
              window.requestAnimationFrame(() => document.getElementById(`shop-tab-${nextId}`)?.focus());
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "packs" && (
        <section id="shop-panel-packs" className="shop-panel" role="tabpanel" aria-labelledby="shop-tab-packs">
          <div className="section-heading"><h2>새로운 카드의 흐름</h2><p>카드팩은 카드 1장을 포함하며 중복 카드도 나올 수 있어요.</p></div>
          <div className="pack-grid">
            {cardPacks.map((pack, index) => (
              <article className="pack-product glass-panel" key={pack.id} style={{ "--pack-accent": pack.accent } as CSSProperties}>
                {index === 1 && <span className="product-ribbon">가장 인기</span>}
                <div className="pack-product__visual" aria-hidden="true"><div className="pack-product__seal"><span>{pack.glyph}</span></div><p>SEA:K</p><strong>{pack.name}</strong><small>발견 카드 한 장</small></div>
                <div className="pack-product__body"><h3>{pack.name}</h3><p>{pack.description}</p><div className="odds-row"><span>에픽 이상 확률</span><strong>{pack.rarityWeights.Epic + pack.rarityWeights.Legendary}%</strong></div><button type="button" className="button button--primary button--wide" disabled={progress.coins < pack.price} onClick={() => onBuyPack(pack.id)}><Coin size="sm" /> {pack.price}<span>{progress.coins < pack.price ? "코인 부족" : "팩 열기"}</span></button></div>
              </article>
            ))}
          </div>
        </section>
      )}

      {tab === "decor" && (
        <section id="shop-panel-decor" className="shop-panel" role="tabpanel" aria-labelledby="shop-tab-decor">
          <div className="section-heading"><h2>나만의 앨범 꾸미기</h2><p>구매한 아이템은 언제든 다시 적용할 수 있어요.</p></div>
          <div className="decor-grid">
            {decorItems.map((item) => {
              const owned = progress.ownedDecor.includes(item.id);
              const active = item.decorType === "frame" ? progress.activeFrame === item.id : progress.activeBackground === item.id;
              return (
                <article className="decor-card" key={item.id} style={{ "--decor-a": item.preview.primary, "--decor-b": item.preview.secondary } as CSSProperties}>
                  <div className="decor-card__preview" data-effect={item.preview.effect} data-type={item.decorType}><span>{item.decorType === "frame" ? "카드" : "앨범"}</span><i /></div>
                  <div className="decor-card__copy"><p className="eyebrow">{item.decorType === "frame" ? "카드 프레임" : "앨범 배경"}</p><h3>{item.name}</h3><p>{item.description}</p><button type="button" className={`button button--wide ${active ? "button--complete" : owned ? "button--ghost" : "button--soft"}`} onClick={() => onDecor(item)}>{active ? "✓ 적용 중" : owned ? "적용하기" : <><Coin size="sm" /> {item.price}<span>구매</span></>}</button></div>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {tab === "rewards" && (
        <section id="shop-panel-rewards" className="shop-panel" role="tabpanel" aria-labelledby="shop-tab-rewards">
          <div className="reward-notice"><span aria-hidden="true">i</span><p><strong>카페·편의점 현장 교환권</strong>코인으로 교환한 뒤 보상함에서 교환 코드를 확인해 매장에 제시하는 흐름을 체험할 수 있어요. 현재는 제휴 전 시연용이며 실제 결제·쿠폰 발급은 이루어지지 않습니다.</p></div>
          <div className="reward-grid">
            {regionRewards.map((reward) => {
              const owned = progress.ownedRewards.includes(reward.id);
              return (
                <article className="reward-card" key={reward.id} style={{ "--reward-a": reward.colors[0], "--reward-b": reward.colors[1] } as CSSProperties}>
                  <div className="reward-card__visual"><span aria-hidden="true">{reward.glyph}</span><small>{regionById[reward.regionId].name} · {reward.venueType}</small></div>
                  <div className="reward-card__copy"><span className="reward-disclaimer">{reward.disclaimer}</span><h3>{reward.name}</h3><p>{reward.description}</p><button type="button" className={`button button--wide ${owned ? "button--complete" : "button--primary"}`} disabled={owned || progress.coins < reward.price} onClick={() => onReward(reward)}>{owned ? "✓ 교환 완료" : <><Coin size="sm" /> {reward.price}<span>{progress.coins < reward.price ? "코인 부족" : "교환권 받기"}</span></>}</button></div>
                </article>
              );
            })}
          </div>
        </section>
      )}

      {tab === "wallet" && (
        <section id="shop-panel-wallet" className="shop-panel reward-wallet" role="tabpanel" aria-labelledby="shop-tab-wallet">
          <div className="section-heading"><h2>내 보상함</h2><p>교환한 가상 지역 혜택은 이 브라우저에 저장됩니다.</p></div>
          {ownedRewards.length ? (
            <div className="reward-grid">
              {ownedRewards.map((reward) => (
                <article className="wallet-ticket" key={reward.id} style={{ "--reward-a": reward.colors[0], "--reward-b": reward.colors[1] } as CSSProperties}>
                  <span aria-hidden="true">{reward.glyph}</span><div><small>{regionById[reward.regionId].name} · {reward.venueType} · {reward.disclaimer}</small><h3>{reward.name}</h3><p>매장 제시 코드 · <strong>{reward.redemptionCode}</strong></p></div><b>사용 전</b>
                </article>
              ))}
            </div>
          ) : <EmptyState glyph="▱" title="아직 교환한 보상이 없어요" description="지역 보상 탭에서 코인으로 가상 혜택을 교환해 보세요." />}
        </section>
      )}
    </div>
  );
}

function MarketScreen({ progress, onTrade }: { progress: ProgressState; onTrade: (id: string) => void }) {
  const availableCount = tradeListings.filter((listing) => !progress.completedTrades.includes(listing.id) && (progress.cards[listing.wantedCardId] ?? 0) > 0).length;
  return (
    <div className="screen">
      <ScreenIntro eyebrow="가상 탐험가 교환" title="파도 교환 장터" description="가상 탐험가들과 중복 카드를 바꿔보세요. 실제 사용자·현금·상품 거래는 없습니다." aside={<div className="market-summary"><span><b>{duplicateCardCount(progress)}</b> 중복 카드</span><span><b>{availableCount}</b> 교환 가능</span></div>} />
      <div className="market-notice"><span aria-hidden="true">i</span><p><strong>시연용 가상 장터예요</strong>교환 결과는 내 앨범과 코인에 즉시 반영되며 각 거래는 한 번만 가능해요.</p></div>
      <div className="trade-list">
        {tradeListings.map((listing) => {
          const wanted = cardById[listing.wantedCardId];
          const offered = cardById[listing.offeredCardId];
          const hasCard = (progress.cards[wanted.id] ?? 0) > 0;
          const completed = progress.completedTrades.includes(listing.id);
          return (
            <article className="trade-card glass-panel" key={listing.id}>
              <header className="trader"><span className="trader__avatar" aria-hidden="true">{listing.trader.avatarGlyph}</span><div><strong>{listing.trader.name}</strong><small>{listing.trader.handle} · 방금 전</small></div><span className="trader__online">접속 중</span></header>
              <p className="trade-card__message">“{listing.message}”</p>
              <div className="trade-flow">
                <div className="trade-side"><p>내가 보내요</p><MiniCard card={wanted} owned={hasCard} photo={progress.cardPhotos[wanted.id]} /><span className={hasCard ? "stock stock--yes" : "stock stock--no"}>{hasCard ? `보유 ${progress.cards[wanted.id]}장` : "카드 없음"}</span></div>
                <div className="trade-arrow"><span>⇄</span>{listing.bonusCoins > 0 && <small>+ <Coin size="sm" /> {listing.bonusCoins}</small>}</div>
                <div className="trade-side"><p>내가 받아요</p><MiniCard card={offered} /><span className="stock stock--receive">{listing.bonusCoins > 0 ? `코인 ${listing.bonusCoins} 추가` : "일대일 교환"}</span></div>
              </div>
              <button type="button" className={`button button--wide ${completed ? "button--complete" : "button--primary"}`} disabled={completed || !hasCard} onClick={() => onTrade(listing.id)}>{completed ? "✓ 교환 완료" : hasCard ? "이 카드로 교환하기" : `‘${wanted.name}’이 필요해요`}</button>
            </article>
          );
        })}
      </div>
    </div>
  );
}

function formatTimeWindow(card: SeaCard) {
  const timeWindow = acquisitionByCardId[card.id].timeWindow;
  if (!timeWindow) return "시간 제한 없음";
  return `${String(timeWindow.startHour).padStart(2, "0")}:00~${String(timeWindow.endHour).padStart(2, "0")}:00`;
}

function CardDetailModal({
  card,
  progress,
  geo,
  onClose,
  onCapture,
  onLocation,
}: {
  card: SeaCard | null;
  progress: ProgressState;
  geo: GeoState;
  onClose: () => void;
  onCapture: (card: SeaCard, file: File) => Promise<boolean>;
  onLocation: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [processing, setProcessing] = useState(false);
  const [clockTick, setClockTick] = useState(() => Date.now());

  useEffect(() => {
    if (!card) return;
    const timer = window.setInterval(() => setClockTick(Date.now()), 30_000);
    return () => window.clearInterval(timer);
  }, [card]);

  if (!card) return null;
  const owned = progress.cards[card.id] ?? 0;
  const region = regionById[card.regionId];
  const rule = acquisitionByCardId[card.id];
  const spot = spotById[rule.spotId];
  const photo = progress.cardPhotos[card.id];
  const evaluation = applyDailyLimit(
    progress,
    card,
    spot.id,
    evaluateAcquisition(
      rule,
      spot,
      geo,
      geo.source === "demo" ? undefined : new Date(clockTick),
    ),
  );
  const mapUrl = `https://map.kakao.com/link/map/${encodeURIComponent(spot.name)},${spot.coordinates.lat},${spot.coordinates.lng}`;
  const directionsUrl = geo.coords
    ? `https://map.kakao.com/link/from/${encodeURIComponent("현재 위치")},${geo.coords.lat},${geo.coords.lng}/to/${encodeURIComponent(spot.name)},${spot.coordinates.lat},${spot.coordinates.lng}`
    : `https://map.kakao.com/link/to/${encodeURIComponent(spot.name)},${spot.coordinates.lat},${spot.coordinates.lng}`;

  const handleFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file || !evaluation.eligible) return;
    setProcessing(true);
    await onCapture(card, file);
    setProcessing(false);
  };

  return (
    <Modal open title={card.name} eyebrow={`바다 카드 · ${String(card.number).padStart(2, "0")}`} onClose={onClose} className="card-detail-modal card-detail-modal--field">
      <div className="card-detail card-detail--field">
        <div className="card-detail__visual card-detail__visual--waves">
          <span className="card-water-glow" aria-hidden="true"><i /><i /></span>
          <SeaCardTile card={card} owned={Math.max(owned, photo ? 1 : 0)} activeFrame={progress.activeFrame} photo={photo} />
        </div>
        <div className="card-detail__copy">
          <div className="card-detail__meta"><RarityBadge rarity={card.rarity} /><span>{region.name}</span>{owned > 0 && <span>보유 {owned}장</span>}{photo && <span>내 사진 기록</span>}</div>
          <p>{card.description}</p>
          <dl className="acquisition-facts">
            <div><dt>획득 가능 장소</dt><dd>{spot.name}<small>{spot.location}</small></dd></div>
            <div><dt>획득 조건</dt><dd>{rule.conditionText}</dd></div>
            <div><dt>촬영 시간</dt><dd>{formatTimeWindow(card)}{geo.source === "demo" && rule.timeWindow && <small>데모 모드에서는 오후 6시 기준</small>}</dd></div>
            <div><dt>현재 거리</dt><dd><strong>{formatDistance(evaluation.distance)}</strong><small>인증 반경 {rule.radiusMeters}m</small></dd></div>
            <div><dt>첫 촬영 보상</dt><dd><Coin size="sm" /> {rule.coinReward}코인 + 카드 한 장</dd></div>
          </dl>
        </div>
      </div>

      <div className="detail-map-wrap">
        <KakaoMap center={geo.coords ?? spot.coordinates} target={spot.coordinates} user={geo.coords} height={235} />
        <div className="map-actions">
          <a className="button button--ghost" href={mapUrl} target="_blank" rel="noreferrer">지도 보기 ↗</a>
          <a className="button button--soft" href={directionsUrl} target="_blank" rel="noreferrer">길찾기 ↗</a>
        </div>
      </div>

      <div className="capture-panel" data-ready={evaluation.eligible}>
        <div className="capture-status">
          <span aria-hidden="true">{evaluation.eligible ? "✓" : "!"}</span>
          <div>
            <strong>{evaluation.eligible ? "촬영 인증 조건을 만족했어요" : "아직 촬영할 수 없어요"}</strong>
            {evaluation.eligible ? (
              <small>{photo ? "사진을 다시 촬영하면 대표 이미지만 교체됩니다." : "카메라로 이 장소만의 장면을 기록해 주세요."}</small>
            ) : (
              <ul>{evaluation.reasons.filter((reason) => !reason.startsWith("데모 위치에서는")).map((reason) => <li key={reason}>{reason}</li>)}</ul>
            )}
          </div>
        </div>
        {geo.status !== "ready" && (
          <button type="button" className="button button--ghost button--wide" onClick={onLocation}>현재 위치 확인하기</button>
        )}
        <input
          ref={fileRef}
          className="visually-hidden"
          tabIndex={-1}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFile}
          aria-label="사진 촬영 또는 선택"
        />
        <button
          type="button"
          className="button button--primary button--wide capture-button"
          disabled={!evaluation.eligible || processing}
          onClick={() => fileRef.current?.click()}
        >
          <span aria-hidden="true">◉</span>
          {processing ? "사진을 압축하여 저장하는 중…" : photo ? "다시 촬영하여 사진 바꾸기" : "촬영하여 카드 획득하기"}
        </button>
        <p>GPS 사용 시 촬영 직전에 위치와 시간을 다시 확인합니다. 사진은 작은 미리보기로 압축되어 이 브라우저의 localStorage에만 저장됩니다.</p>
      </div>
    </Modal>
  );
}

function RevealModal({
  reveal,
  packStage,
  progress,
  onClose,
  onAlbum,
}: {
  reveal: { card: SeaCard; coins: number; source: "촬영" | "카드팩" | "교환"; title: string } | null;
  packStage: "opening" | "revealed";
  progress: ProgressState;
  onClose: () => void;
  onAlbum: () => void;
}) {
  if (!reveal) return null;
  const isOpening = reveal.source === "카드팩" && packStage === "opening";
  return (
    <Modal open title={reveal.title} eyebrow={`${reveal.source} 완료`} onClose={onClose} className="reveal-modal">
      <div className={`reveal-stage ${isOpening ? "is-opening" : "is-revealed"}`}>
        {isOpening ? (
          <div className="opening-pack" aria-label="카드팩 개봉 중"><div className="opening-pack__top" /><div className="opening-pack__seal">SEA:K<span>?</span></div><i /><i /><i /></div>
        ) : (
          <div className="revealed-card"><SeaCardTile card={reveal.card} owned={progress.cards[reveal.card.id] ?? 1} activeFrame={progress.activeFrame} photo={progress.cardPhotos[reveal.card.id]} /><div className="revealed-card__flare" aria-hidden="true" /></div>
        )}
      </div>
      {!isOpening && <div className="reveal-copy"><p>{reveal.source === "촬영" ? "나만의 부산 바다 장면을 카드에 기록했어요" : reveal.source === "카드팩" ? "팩에서 새로운 바다의 흐름이 깨어났어요" : "교환 카드가 앨범에 도착했어요"}</p><h3>{reveal.card.name}</h3><div><RarityBadge rarity={reveal.card.rarity} /><span>{regionById[reveal.card.regionId].name}</span>{reveal.coins > 0 && <strong><Coin size="sm" /> +{reveal.coins}</strong>}</div></div>}
      <div className="modal-actions"><button type="button" className="button button--ghost" onClick={onClose}>{isOpening ? "잠시만요…" : "계속 둘러보기"}</button><button type="button" className="button button--primary" onClick={onAlbum} disabled={isOpening}>앨범에서 확인 <span>→</span></button></div>
    </Modal>
  );
}
