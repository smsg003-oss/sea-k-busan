import { SeaKApp } from "./SeaKApp";

export default function Home() {
  return <SeaKApp />;
}
