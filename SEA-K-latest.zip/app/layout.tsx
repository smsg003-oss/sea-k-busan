import type { Metadata, Viewport } from "next";
import { headers } from "next/headers";
import Script from "next/script";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host =
    requestHeaders.get("x-forwarded-host") ??
    requestHeaders.get("host") ??
    "localhost:3000";
  const protocol =
    requestHeaders.get("x-forwarded-proto") ??
    (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;
  const title = "SEA:K — 부산 바다 발견 수집";
  const description =
    "부산 바다에서만 만날 수 있는 장소, 문화, 풍경을 발견하고 카드로 수집하세요.";
  const socialImage = `${origin}/og.png`;

  return {
    title,
    description,
    applicationName: "SEA:K",
    keywords: ["부산", "바다", "여행", "관광", "카드 수집", "SEA:K"],
    openGraph: {
      title,
      description,
      type: "website",
      locale: "ko_KR",
      url: origin,
      siteName: "SEA:K",
      images: [{ url: socialImage, width: 1733, height: 908, alt: "SEA:K 부산 바다 발견 수집" }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: [socialImage],
    },
  };
}

export const viewport: Viewport = {
  themeColor: "#03141f",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <head>
        <Script src="/kakao-config.js" strategy="beforeInteractive" />
      </head>
      <body>{children}</body>
    </html>
  );
}
