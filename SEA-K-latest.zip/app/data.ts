export type Rarity = "Common" | "Rare" | "Epic" | "Legendary";

export type RegionId =
  | "haeundae"
  | "gwangalli"
  | "yeongdo"
  | "dadaepo"
  | "gijang";

export interface Coordinates {
  lat: number;
  lng: number;
}

export type CardTag =
  | "등대"
  | "갈매기"
  | "파도"
  | "모래"
  | "노을"
  | "항구"
  | "컨테이너"
  | "어시장"
  | "해안 산책로"
  | "야경"
  | "바람"
  | "해녀"
  | "미역"
  | "절벽"
  | "어선";

export interface Region {
  id: RegionId;
  name: string;
  englishName: string;
  tagline: string;
  description: string;
  accent: string;
  gradient: [string, string];
  glyph: string;
}

export interface CardVisual {
  motif: string;
  glyph: string;
  gradient: [string, string, string];
  glow: string;
}

export interface SeaCard {
  id: string;
  number: number;
  name: string;
  rarity: Rarity;
  description: string;
  regionId: RegionId;
  tags: CardTag[];
  visual: CardVisual;
}

export interface ExplorationSpot {
  id: string;
  regionId: RegionId;
  name: string;
  location: string;
  coordinates: Coordinates;
  description: string;
  discoveryPrompt: string;
  possibleRarities: Rarity[];
  coinReward: {
    min: number;
    max: number;
  };
  visual: {
    glyph: string;
    gradient: [string, string];
    pattern: "wave" | "beam" | "spark" | "sand" | "current";
  };
}

export interface CardAcquisitionRule {
  cardId: string;
  spotId: string;
  radiusMeters: number;
  conditionText: string;
  timeWindow?: {
    startHour: number;
    endHour: number;
  };
  coinReward: number;
}

export interface RegionReward {
  id: string;
  name: string;
  description: string;
  price: number;
  regionId: RegionId;
  disclaimer: "시연용 가상 혜택" | "제휴 시 제공 예정";
  glyph: string;
  colors: [string, string];
  venueType: "카페" | "편의점" | "지역 문화 공간";
  redemptionCode: string;
}

export interface TradeListing {
  id: string;
  trader: {
    name: string;
    handle: string;
    avatarGlyph: string;
  };
  wantedCardId: string;
  offeredCardId: string;
  bonusCoins: number;
  message: string;
}

export interface CardPack {
  id: string;
  kind: "pack";
  name: string;
  description: string;
  price: number;
  drawCount: number;
  accent: string;
  glyph: string;
  rarityWeights: Record<Rarity, number>;
}

export type DecorType = "frame" | "album-background";

export interface DecorItem {
  id: string;
  kind: "decor";
  decorType: DecorType;
  name: string;
  description: string;
  price: number;
  preview: {
    primary: string;
    secondary: string;
    effect: "glow" | "shimmer" | "bubbles" | "grid";
  };
}

export const rarityMeta: Record<
  Rarity,
  { label: string; color: string; sortOrder: number }
> = {
  Common: { label: "커먼", color: "#78E6D0", sortOrder: 1 },
  Rare: { label: "레어", color: "#39A7FF", sortOrder: 2 },
  Epic: { label: "에픽", color: "#9D7BFF", sortOrder: 3 },
  Legendary: { label: "레전더리", color: "#FF7E70", sortOrder: 4 },
};

export const regions: Region[] = [
  {
    id: "haeundae",
    name: "해운대",
    englishName: "HAEUNDAE",
    tagline: "도시의 빛이 파도에 번지는 곳",
    description: "백사장과 달맞이 언덕 사이, 부산의 푸른 리듬을 찾는다.",
    accent: "#42D9FF",
    gradient: ["#087FB5", "#14D7CB"],
    glyph: "≈",
  },
  {
    id: "gwangalli",
    name: "광안리",
    englishName: "GWANGALLI",
    tagline: "밤바다에 다리가 별자리를 그리는 곳",
    description: "광안대교 아래 겹쳐지는 네온과 잔물결을 수집한다.",
    accent: "#8F8CFF",
    gradient: ["#273B9B", "#9A62E8"],
    glyph: "◇",
  },
  {
    id: "yeongdo",
    name: "영도",
    englishName: "YEONGDO",
    tagline: "절벽과 항구가 오래된 이야기를 품은 섬",
    description: "뱃고동, 등대, 골목의 결을 따라 항구의 시간을 발견한다.",
    accent: "#FF9B72",
    gradient: ["#17465D", "#E47357"],
    glyph: "△",
  },
  {
    id: "dadaepo",
    name: "다대포",
    englishName: "DADAEPO",
    tagline: "넓은 모래 위로 하루의 끝이 내려앉는 곳",
    description: "갯벌의 무늬와 거대한 노을 속에서 느린 빛을 줍는다.",
    accent: "#FF806E",
    gradient: ["#E95862", "#FFBB6A"],
    glyph: "◒",
  },
  {
    id: "gijang",
    name: "기장",
    englishName: "GIJANG",
    tagline: "거친 파도와 해녀의 숨이 만나는 해안",
    description: "바위 해안과 어촌의 생명력 속 깊고 선명한 바다를 만난다.",
    accent: "#43E5B1",
    gradient: ["#075E68", "#27C98C"],
    glyph: "✦",
  },
];

export const cards: SeaCard[] = [
  {
    id: "haeundae-foam-letter",
    number: 1,
    name: "포말의 편지",
    rarity: "Common",
    description: "아침 파도가 백사장에 남긴 한 줄의 푸른 안부.",
    regionId: "haeundae",
    tags: ["파도", "모래"],
    visual: {
      motif: "겹친 포말 원과 유리처럼 맑은 수평선",
      glyph: "≈",
      gradient: ["#074E8A", "#1BB9DD", "#B8FFF2"],
      glow: "#82FFF0",
    },
  },
  {
    id: "haeundae-dalmajigil-wind",
    number: 2,
    name: "달맞이 바람결",
    rarity: "Common",
    description: "소나무 사이를 돌아 해안 산책로로 내려온 가벼운 바람.",
    regionId: "haeundae",
    tags: ["해안 산책로", "바람"],
    visual: {
      motif: "초승달을 감싸는 세 갈래 바람선",
      glyph: "☾",
      gradient: ["#10244A", "#3478A7", "#6BE0C4"],
      glow: "#A2FFE7",
    },
  },
  {
    id: "haeundae-mipo-whistle",
    number: 3,
    name: "미포의 휘파람",
    rarity: "Rare",
    description: "작은 항구를 깨우며 붉은 부표 사이를 누비는 갈매기의 신호.",
    regionId: "haeundae",
    tags: ["갈매기", "항구"],
    visual: {
      motif: "날개 궤적과 산호빛 부표의 리듬",
      glyph: "⌁",
      gradient: ["#075B83", "#15B9BE", "#FF7E70"],
      glow: "#FFB7A9",
    },
  },
  {
    id: "haeundae-blue-hour",
    number: 4,
    name: "청시의 해변",
    rarity: "Epic",
    description: "낮과 밤 사이 단 몇 분, 모든 파도가 남빛으로 멈추는 순간.",
    regionId: "haeundae",
    tags: ["파도", "야경"],
    visual: {
      motif: "푸른 시간환과 은빛 파도의 중첩",
      glyph: "◉",
      gradient: ["#07152F", "#263EAA", "#5ADBE8"],
      glow: "#799BFF",
    },
  },
  {
    id: "gwangalli-pebble-beat",
    number: 5,
    name: "몽돌 비트",
    rarity: "Common",
    description: "잔물결이 조약돌을 두드려 만드는 광안리만의 작은 박자.",
    regionId: "gwangalli",
    tags: ["파도", "모래"],
    visual: {
      motif: "동심파 안에서 튀어 오르는 매끈한 몽돌",
      glyph: "●",
      gradient: ["#132755", "#2764A5", "#53D6D2"],
      glow: "#8EF8E9",
    },
  },
  {
    id: "gwangalli-night-current",
    number: 6,
    name: "밤물결 스텝",
    rarity: "Common",
    description: "해변의 음악을 따라 네온빛 물결이 한 칸씩 움직인다.",
    regionId: "gwangalli",
    tags: ["야경", "파도"],
    visual: {
      motif: "신시사이저 파형처럼 꺾이는 네온 파도",
      glyph: "⌇",
      gradient: ["#101333", "#594BCB", "#ED66B6"],
      glow: "#FF82DB",
    },
  },
  {
    id: "gwangalli-bridge-prism",
    number: 7,
    name: "브리지 프리즘",
    rarity: "Rare",
    description: "광안대교의 빛을 일곱 겹으로 접어 품은 바다의 조각.",
    regionId: "gwangalli",
    tags: ["야경", "해안 산책로"],
    visual: {
      motif: "현수교 선을 통과해 갈라지는 무지갯빛 광선",
      glyph: "◇",
      gradient: ["#171A55", "#6757E7", "#3BF0DD"],
      glow: "#B69DFF",
    },
  },
  {
    id: "gwangalli-diamond-tide",
    number: 8,
    name: "다이아몬드 타이드",
    rarity: "Legendary",
    description: "도시의 별빛이 만조와 맞닿을 때 깨어나는 보랏빛 조류.",
    regionId: "gwangalli",
    tags: ["야경", "파도"],
    visual: {
      motif: "다이아몬드 파편과 거대한 자주색 조류환",
      glyph: "✧",
      gradient: ["#080C2B", "#6835C8", "#52E1E9"],
      glow: "#ECA4FF",
    },
  },
  {
    id: "yeongdo-cliff-breath",
    number: 9,
    name: "절영의 숨",
    rarity: "Common",
    description: "태종대 절벽 아래에서 하얗게 부서졌다 다시 모이는 바람.",
    regionId: "yeongdo",
    tags: ["절벽", "바람"],
    visual: {
      motif: "현무암 절벽을 타고 오르는 흰 나선",
      glyph: "〽",
      gradient: ["#122B39", "#23627A", "#D1EEE3"],
      glow: "#B9FFE7",
    },
  },
  {
    id: "yeongdo-market-silver",
    number: 10,
    name: "은비늘 새벽장",
    rarity: "Common",
    description: "새벽 어시장의 좌판마다 작은 달처럼 반짝이는 은빛 비늘.",
    regionId: "yeongdo",
    tags: ["어시장", "항구"],
    visual: {
      motif: "격자 좌판 위로 흐르는 은빛 물고기 궤적",
      glyph: "><>",
      gradient: ["#183745", "#3D7D83", "#C7E7D7"],
      glow: "#ECFFF3",
    },
  },
  {
    id: "yeongdo-container-sparks",
    number: 11,
    name: "컨테이너 성운",
    rarity: "Rare",
    description: "밤 항구의 컨테이너가 별자리처럼 이어져 만든 육지의 성운.",
    regionId: "yeongdo",
    tags: ["컨테이너", "항구", "야경"],
    visual: {
      motif: "색색의 직육면체와 크레인 별자리",
      glyph: "▦",
      gradient: ["#102432", "#E15C55", "#F2B84B"],
      glow: "#FF946F",
    },
  },
  {
    id: "yeongdo-taejong-light",
    number: 12,
    name: "태종의 유도광",
    rarity: "Epic",
    description: "짙은 안개를 가르고 먼 배의 귀환을 끝까지 지켜보는 등대빛.",
    regionId: "yeongdo",
    tags: ["등대", "절벽", "어선"],
    visual: {
      motif: "붉은 등대에서 펼쳐지는 부채꼴 금빛 광선",
      glyph: "⌃",
      gradient: ["#081A27", "#A63F43", "#FFD36E"],
      glow: "#FFE6A1",
    },
  },
  {
    id: "dadaepo-sand-script",
    number: 13,
    name: "모래의 문장",
    rarity: "Common",
    description: "바람과 게 발자국이 넓은 백사장에 함께 써 내려간 비밀 글씨.",
    regionId: "dadaepo",
    tags: ["모래", "바람"],
    visual: {
      motif: "사선 바람무늬와 점선으로 이어진 게 발자국",
      glyph: "∴",
      gradient: ["#B56B52", "#E9AA72", "#FFE1A6"],
      glow: "#FFD59B",
    },
  },
  {
    id: "dadaepo-reed-glimmer",
    number: 14,
    name: "갈대의 잔광",
    rarity: "Common",
    description: "낙동강 끝자락의 바람을 붙잡고 오래 흔들리는 금빛 잔상.",
    regionId: "dadaepo",
    tags: ["해안 산책로", "바람"],
    visual: {
      motif: "긴 갈대 선 사이로 번지는 낮은 원형 빛",
      glyph: "╱",
      gradient: ["#7A5842", "#CAA25B", "#FBE3A0"],
      glow: "#FFE690",
    },
  },
  {
    id: "dadaepo-orange-horizon",
    number: 15,
    name: "오렌지 수평선",
    rarity: "Rare",
    description: "해와 바다가 같은 색이 되는 순간, 수평선이 켜는 한 줄의 불빛.",
    regionId: "dadaepo",
    tags: ["노을", "파도"],
    visual: {
      motif: "태양을 가로지르는 선명한 한 줄 수평선",
      glyph: "⊖",
      gradient: ["#7A3158", "#F06462", "#FFB65B"],
      glow: "#FF9A66",
    },
  },
  {
    id: "dadaepo-sunset-gate",
    number: 16,
    name: "낙조의 문",
    rarity: "Legendary",
    description: "붉은 해가 갯벌에 닿을 때 단 한 번 열리는 하루 끝의 문.",
    regionId: "dadaepo",
    tags: ["노을", "모래"],
    visual: {
      motif: "거울 같은 갯벌 위에 선 거대한 태양 아치",
      glyph: "◒",
      gradient: ["#31193B", "#D94559", "#FFC35C"],
      glow: "#FF776D",
    },
  },
  {
    id: "gijang-seaweed-forest",
    number: 17,
    name: "미역숲 숨바꼭질",
    rarity: "Common",
    description: "맑은 물 아래 초록 리본처럼 흔들리며 어린 물고기를 숨겨주는 숲.",
    regionId: "gijang",
    tags: ["미역", "해녀"],
    visual: {
      motif: "위로 피어오르는 미역 리본과 작은 물고기 점",
      glyph: "≋",
      gradient: ["#074D53", "#159A76", "#78E6A8"],
      glow: "#70FFC0",
    },
  },
  {
    id: "gijang-fisher-signal",
    number: 18,
    name: "어선의 모스",
    rarity: "Rare",
    description: "새벽 수평선의 어선들이 점과 빛으로 주고받는 조용한 인사.",
    regionId: "gijang",
    tags: ["어선", "항구", "야경"],
    visual: {
      motif: "점멸하는 세 개의 집어등과 파도 위 점선",
      glyph: "·–·",
      gradient: ["#062D41", "#0C7D84", "#FFE178"],
      glow: "#FFF1A2",
    },
  },
  {
    id: "gijang-yeonhwa-star",
    number: 19,
    name: "연화리 해녀별",
    rarity: "Epic",
    description: "깊은 물에서 건져 올린 숨 한 모금이 수면 위에서 별로 피어난다.",
    regionId: "gijang",
    tags: ["해녀", "어시장"],
    visual: {
      motif: "물방울 별과 원형으로 퍼지는 숨비소리 파문",
      glyph: "✦",
      gradient: ["#063D50", "#13A391", "#9FF2D5"],
      glow: "#B9FFE8",
    },
  },
  {
    id: "gijang-orangkae-beacon",
    number: 20,
    name: "오랑대 파수광",
    rarity: "Epic",
    description: "거친 파도를 한 걸음도 물러서지 않고 지켜내는 청록빛 등대의 심장.",
    regionId: "gijang",
    tags: ["등대", "파도", "절벽"],
    visual: {
      motif: "바위 위 등대와 방패처럼 솟는 청록 파도",
      glyph: "♢",
      gradient: ["#052F41", "#087F80", "#43E5B1"],
      glow: "#61FFD0",
    },
  },
];

export const explorationSpots: ExplorationSpot[] = [
  {
    id: "haeundae-beach",
    regionId: "haeundae",
    coordinates: { lat: 35.1587, lng: 129.1604 },
    name: "해운대 백사장",
    location: "해운대해수욕장 중앙",
    description: "도심과 바다가 맞닿는 부산의 대표 수평선을 걸어요.",
    discoveryPrompt: "파도가 가장 길게 남긴 선을 찾아보세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 70, max: 110 },
    visual: {
      glyph: "≈",
      gradient: ["#087FB5", "#5DE9D1"],
      pattern: "wave",
    },
  },
  {
    id: "haeundae-mipo",
    regionId: "haeundae",
    coordinates: { lat: 35.1596, lng: 129.171 },
    name: "미포 끝집",
    location: "미포항 방파제 입구",
    description: "작은 어선과 해안열차가 스쳐 가는 바다 모퉁이예요.",
    discoveryPrompt: "붉은 부표 너머 갈매기의 궤적을 따라가세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 80, max: 120 },
    visual: {
      glyph: "⌁",
      gradient: ["#075B83", "#FF7E70"],
      pattern: "beam",
    },
  },
  {
    id: "gwangalli-beach",
    regionId: "gwangalli",
    coordinates: { lat: 35.1532, lng: 129.1187 },
    name: "광안리 물빛무대",
    location: "광안리해수욕장 만남의 광장",
    description: "광안대교와 잔물결이 매일 다른 무대를 만드는 해변이에요.",
    discoveryPrompt: "다리의 불빛이 물에 닿는 지점을 찾아보세요.",
    possibleRarities: ["Common", "Rare", "Epic", "Legendary"],
    coinReward: { min: 75, max: 115 },
    visual: {
      glyph: "◇",
      gradient: ["#273B9B", "#B563DE"],
      pattern: "spark",
    },
  },
  {
    id: "gwangalli-millak",
    regionId: "gwangalli",
    coordinates: { lat: 35.1548, lng: 129.1316 },
    name: "민락 수변선",
    location: "민락수변공원 해안 데크",
    description: "바다 가까이 앉아 도시 야경의 맥박을 듣는 산책선이에요.",
    discoveryPrompt: "파도와 네온이 같은 박자로 반짝일 때를 기다리세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 80, max: 125 },
    visual: {
      glyph: "⌇",
      gradient: ["#191A51", "#ED66B6"],
      pattern: "wave",
    },
  },
  {
    id: "yeongdo-taejongdae",
    regionId: "yeongdo",
    coordinates: { lat: 35.0531, lng: 129.0872 },
    name: "태종대 등대길",
    location: "태종대 영도등대 전망대",
    description: "절벽 아래 부서지는 파도와 먼 수평선을 마주하는 길이에요.",
    discoveryPrompt: "등대빛이 향하는 먼 바다를 바라보세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 90, max: 135 },
    visual: {
      glyph: "⌃",
      gradient: ["#183A49", "#E66D57"],
      pattern: "beam",
    },
  },
  {
    id: "yeongdo-kangkangee",
    regionId: "yeongdo",
    coordinates: { lat: 35.0908, lng: 129.0402 },
    name: "깡깡이 항구골목",
    location: "대평동 깡깡이예술마을",
    description: "수리조선소의 금속음과 항구 풍경이 겹치는 오래된 골목이에요.",
    discoveryPrompt: "크레인 선들이 만드는 기하학을 찾아보세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 85, max: 130 },
    visual: {
      glyph: "▦",
      gradient: ["#164455", "#F09265"],
      pattern: "spark",
    },
  },
  {
    id: "dadaepo-sunset",
    regionId: "dadaepo",
    coordinates: { lat: 35.0466, lng: 128.9656 },
    name: "다대포 낙조선",
    location: "다대포해수욕장 낙조분수 앞",
    description: "넓은 갯벌 위로 노을이 천천히 길어지는 해변이에요.",
    discoveryPrompt: "물 위에 생긴 두 번째 태양을 찾아보세요.",
    possibleRarities: ["Common", "Rare", "Epic", "Legendary"],
    coinReward: { min: 80, max: 125 },
    visual: {
      glyph: "◒",
      gradient: ["#D64E61", "#FFBE64"],
      pattern: "sand",
    },
  },
  {
    id: "dadaepo-gouni",
    regionId: "dadaepo",
    coordinates: { lat: 35.0505, lng: 128.9632 },
    name: "고우니 생태길",
    location: "다대포 고우니생태길",
    description: "갈대와 갯벌 생물이 함께 숨 쉬는 낮은 바다 산책로예요.",
    discoveryPrompt: "바람이 지나간 갈대의 방향을 읽어보세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 70, max: 115 },
    visual: {
      glyph: "╱",
      gradient: ["#9A6C4C", "#F4D383"],
      pattern: "sand",
    },
  },
  {
    id: "gijang-yeonhwa",
    regionId: "gijang",
    coordinates: { lat: 35.2189, lng: 129.2275 },
    name: "연화리 숨비항",
    location: "연화리 해녀촌 앞",
    description: "해녀의 숨비소리와 작은 어선이 오가는 생생한 포구예요.",
    discoveryPrompt: "수면 위로 번지는 둥근 숨의 파문을 상상해보세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 85, max: 130 },
    visual: {
      glyph: "✦",
      gradient: ["#075B63", "#4BE1A8"],
      pattern: "current",
    },
  },
  {
    id: "gijang-orangdae",
    regionId: "gijang",
    coordinates: { lat: 35.2058, lng: 129.2274 },
    name: "오랑대 파도단",
    location: "오랑대공원 해안 바위길",
    description: "검은 바위와 힘찬 파도가 정면으로 만나는 거친 해안이에요.",
    discoveryPrompt: "가장 높이 솟은 파도의 청록 끝을 포착하세요.",
    possibleRarities: ["Common", "Rare", "Epic"],
    coinReward: { min: 90, max: 140 },
    visual: {
      glyph: "♢",
      gradient: ["#06485C", "#38D7A4"],
      pattern: "wave",
    },
  },
];

export const cardAcquisitionRules: Record<string, CardAcquisitionRule> = {
  "haeundae-foam-letter": {
    cardId: "haeundae-foam-letter",
    spotId: "haeundae-beach",
    radiusMeters: 300,
    conditionText: "해운대해수욕장 반경 300m 이내에서 파도와 백사장을 촬영하세요.",
    coinReward: 80,
  },
  "haeundae-dalmajigil-wind": {
    cardId: "haeundae-dalmajigil-wind",
    spotId: "haeundae-mipo",
    radiusMeters: 300,
    conditionText: "미포 산책길 반경 300m 이내에서 바닷바람이 느껴지는 풍경을 촬영하세요.",
    coinReward: 80,
  },
  "haeundae-mipo-whistle": {
    cardId: "haeundae-mipo-whistle",
    spotId: "haeundae-mipo",
    radiusMeters: 300,
    conditionText: "미포항 반경 300m 이내에서 방파제나 작은 어선을 촬영하세요.",
    coinReward: 100,
  },
  "haeundae-blue-hour": {
    cardId: "haeundae-blue-hour",
    spotId: "haeundae-beach",
    radiusMeters: 300,
    conditionText: "해운대해수욕장 반경 300m 이내에서 오후 6시부터 9시 사이의 푸른 바다를 촬영하세요.",
    timeWindow: { startHour: 18, endHour: 21 },
    coinReward: 130,
  },
  "gwangalli-pebble-beat": {
    cardId: "gwangalli-pebble-beat",
    spotId: "gwangalli-beach",
    radiusMeters: 300,
    conditionText: "광안리해수욕장 반경 300m 이내에서 몽돌이나 물결 무늬를 촬영하세요.",
    coinReward: 75,
  },
  "gwangalli-night-current": {
    cardId: "gwangalli-night-current",
    spotId: "gwangalli-beach",
    radiusMeters: 300,
    conditionText: "광안리해수욕장 반경 300m 이내에서 오후 6시부터 11시 사이의 야경을 촬영하세요.",
    timeWindow: { startHour: 18, endHour: 23 },
    coinReward: 90,
  },
  "gwangalli-bridge-prism": {
    cardId: "gwangalli-bridge-prism",
    spotId: "gwangalli-millak",
    radiusMeters: 300,
    conditionText: "민락수변공원 반경 300m 이내에서 오후 6시부터 11시 사이 광안대교의 빛을 촬영하세요.",
    timeWindow: { startHour: 18, endHour: 23 },
    coinReward: 115,
  },
  "gwangalli-diamond-tide": {
    cardId: "gwangalli-diamond-tide",
    spotId: "gwangalli-beach",
    radiusMeters: 300,
    conditionText: "광안리해수욕장 반경 300m 이내에서 오후 7시부터 11시 사이 반짝이는 바다를 촬영하세요.",
    timeWindow: { startHour: 19, endHour: 23 },
    coinReward: 180,
  },
  "yeongdo-cliff-breath": {
    cardId: "yeongdo-cliff-breath",
    spotId: "yeongdo-taejongdae",
    radiusMeters: 300,
    conditionText: "태종대 등대길 반경 300m 이내에서 절벽과 수평선을 촬영하세요.",
    coinReward: 85,
  },
  "yeongdo-market-silver": {
    cardId: "yeongdo-market-silver",
    spotId: "yeongdo-kangkangee",
    radiusMeters: 300,
    conditionText: "깡깡이예술마을 반경 300m 이내에서 오전 5시부터 10시 사이 항구의 아침 풍경을 촬영하세요.",
    timeWindow: { startHour: 5, endHour: 10 },
    coinReward: 95,
  },
  "yeongdo-container-sparks": {
    cardId: "yeongdo-container-sparks",
    spotId: "yeongdo-kangkangee",
    radiusMeters: 300,
    conditionText: "깡깡이예술마을 반경 300m 이내에서 조선소 골목의 색과 질감을 촬영하세요.",
    coinReward: 110,
  },
  "yeongdo-taejong-light": {
    cardId: "yeongdo-taejong-light",
    spotId: "yeongdo-taejongdae",
    radiusMeters: 300,
    conditionText: "태종대 등대길 반경 300m 이내에서 등대 또는 바다를 비추는 빛을 촬영하세요.",
    coinReward: 145,
  },
  "dadaepo-sand-script": {
    cardId: "dadaepo-sand-script",
    spotId: "dadaepo-sunset",
    radiusMeters: 300,
    conditionText: "다대포해수욕장 반경 300m 이내에서 모래 위 바람과 발자국의 무늬를 촬영하세요.",
    coinReward: 75,
  },
  "dadaepo-reed-glimmer": {
    cardId: "dadaepo-reed-glimmer",
    spotId: "dadaepo-gouni",
    radiusMeters: 300,
    conditionText: "고우니생태길 반경 300m 이내에서 갈대와 습지의 빛을 촬영하세요.",
    coinReward: 80,
  },
  "dadaepo-orange-horizon": {
    cardId: "dadaepo-orange-horizon",
    spotId: "dadaepo-sunset",
    radiusMeters: 300,
    conditionText: "다대포해수욕장 반경 300m 이내에서 오후 5시부터 8시 사이 주황빛 수평선을 촬영하세요.",
    timeWindow: { startHour: 17, endHour: 20 },
    coinReward: 115,
  },
  "dadaepo-sunset-gate": {
    cardId: "dadaepo-sunset-gate",
    spotId: "dadaepo-sunset",
    radiusMeters: 300,
    conditionText: "다대포해수욕장 반경 300m 이내에서 오후 5시부터 8시 사이 해가 지는 순간을 촬영하세요.",
    timeWindow: { startHour: 17, endHour: 20 },
    coinReward: 180,
  },
  "gijang-seaweed-forest": {
    cardId: "gijang-seaweed-forest",
    spotId: "gijang-yeonhwa",
    radiusMeters: 300,
    conditionText: "연화리 해안 반경 300m 이내에서 미역이나 초록빛 해양 풍경을 촬영하세요.",
    coinReward: 80,
  },
  "gijang-fisher-signal": {
    cardId: "gijang-fisher-signal",
    spotId: "gijang-yeonhwa",
    radiusMeters: 300,
    conditionText: "연화리 해안 반경 300m 이내에서 오전 5시부터 9시 사이 출항하는 어선을 촬영하세요.",
    timeWindow: { startHour: 5, endHour: 9 },
    coinReward: 115,
  },
  "gijang-yeonhwa-star": {
    cardId: "gijang-yeonhwa-star",
    spotId: "gijang-yeonhwa",
    radiusMeters: 300,
    conditionText: "연화리 해안 반경 300m 이내에서 등대나 해녀촌의 독특한 실루엣을 촬영하세요.",
    coinReward: 140,
  },
  "gijang-orangkae-beacon": {
    cardId: "gijang-orangkae-beacon",
    spotId: "gijang-orangdae",
    radiusMeters: 300,
    conditionText: "오랑대공원 반경 300m 이내에서 바위 해안과 청록빛 파도를 촬영하세요.",
    coinReward: 140,
  },
};

export const regionRewards: RegionReward[] = [
  {
    id: "reward-haeundae-cafe",
    name: "해운대 카페 10% 할인권",
    description: "해운대 바다 산책 뒤 카페에서 사용할 수 있다고 가정한 체험형 할인권입니다.",
    price: 240,
    regionId: "haeundae",
    disclaimer: "시연용 가상 혜택",
    glyph: "☕",
    colors: ["#087FB5", "#5DE9D1"],
    venueType: "카페",
    redemptionCode: "SEAK-HAE-CAFE",
  },
  {
    id: "reward-gwangalli-goods",
    name: "광안리 굿즈 교환권",
    description: "광안리 한정 바다 굿즈로 교환할 수 있다고 가정한 디지털 교환권입니다.",
    price: 300,
    regionId: "gwangalli",
    disclaimer: "제휴 시 제공 예정",
    glyph: "◇",
    colors: ["#273B9B", "#B563DE"],
    venueType: "지역 문화 공간",
    redemptionCode: "SEAK-GWA-GOODS",
  },
  {
    id: "reward-yeongdo-postcard",
    name: "영도 항구 엽서 세트",
    description: "영도의 등대와 항구 풍경을 담은 엽서를 받을 수 있다고 가정한 체험 보상입니다.",
    price: 180,
    regionId: "yeongdo",
    disclaimer: "시연용 가상 혜택",
    glyph: "▣",
    colors: ["#17465D", "#E47357"],
    venueType: "카페",
    redemptionCode: "SEAK-YEO-POST",
  },
  {
    id: "reward-dadaepo-festival",
    name: "다대포 축제 우선 입장권",
    description: "다대포 해변 축제의 전용 입장 줄을 이용할 수 있다고 가정한 체험권입니다.",
    price: 360,
    regionId: "dadaepo",
    disclaimer: "제휴 시 제공 예정",
    glyph: "☀",
    colors: ["#D64E61", "#FFBE64"],
    venueType: "지역 문화 공간",
    redemptionCode: "SEAK-DAD-FEST",
  },
  {
    id: "reward-gijang-market",
    name: "기장 해안마을 음료권",
    description: "기장 해안마을 방문 시 음료 한 잔을 받을 수 있다고 가정한 디지털 보상입니다.",
    price: 220,
    regionId: "gijang",
    disclaimer: "시연용 가상 혜택",
    glyph: "♒",
    colors: ["#075E68", "#27C98C"],
    venueType: "편의점",
    redemptionCode: "SEAK-GIJ-DRINK",
  },
  {
    id: "reward-gwangalli-convenience",
    name: "광안리 바다음료 교환권",
    description: "광안리 인근 편의점에서 음료 1개로 교환하는 흐름을 체험하는 시연용 교환권입니다.",
    price: 160,
    regionId: "gwangalli",
    disclaimer: "시연용 가상 혜택",
    glyph: "🥤",
    colors: ["#11688B", "#79E6DF"],
    venueType: "편의점",
    redemptionCode: "SEAK-GWA-DRINK",
  },
];

export const tradeListings: TradeListing[] = [
  {
    id: "trade-wave-note",
    trader: { name: "파도우체부", handle: "@wave.note", avatarGlyph: "≈" },
    wantedCardId: "haeundae-foam-letter",
    offeredCardId: "gwangalli-bridge-prism",
    bonusCoins: 20,
    message: "첫 파도의 문장을 찾고 있어요. 빛나는 다리 조각과 바꿔요!",
  },
  {
    id: "trade-port-signal",
    trader: { name: "새벽집어등", handle: "@04am.light", avatarGlyph: "✦" },
    wantedCardId: "yeongdo-container-sparks",
    offeredCardId: "gijang-fisher-signal",
    bonusCoins: 35,
    message: "항구 야경 컬렉션의 마지막 칸을 채우는 중이에요.",
  },
  {
    id: "trade-sunset-club",
    trader: { name: "낙조수집가", handle: "@last.sun", avatarGlyph: "◒" },
    wantedCardId: "dadaepo-orange-horizon",
    offeredCardId: "yeongdo-taejong-light",
    bonusCoins: 0,
    message: "노을 한 줄과 길을 비추는 등대빛을 교환해요.",
  },
  {
    id: "trade-green-diver",
    trader: { name: "초록잠수부", handle: "@deep.green", avatarGlyph: "≋" },
    wantedCardId: "gijang-seaweed-forest",
    offeredCardId: "haeundae-blue-hour",
    bonusCoins: 15,
    message: "바닷속 숲을 만나면 푸른 시간 한 장을 드릴게요.",
  },
  {
    id: "trade-night-rider",
    trader: { name: "해안선러너", handle: "@coast.runner", avatarGlyph: "◇" },
    wantedCardId: "gwangalli-night-current",
    offeredCardId: "dadaepo-reed-glimmer",
    bonusCoins: 25,
    message: "야간 산책 덱에 꼭 필요한 리듬이에요. 코인도 얹을게요!",
  },
];

export const cardPacks: CardPack[] = [
  {
    id: "pack-sea-breeze",
    kind: "pack",
    name: "씨 브리즈 팩",
    description: "부산 전 지역 카드 1장이 담긴 가벼운 첫 팩.",
    price: 120,
    drawCount: 1,
    accent: "#42E0CE",
    glyph: "≈",
    rarityWeights: { Common: 62, Rare: 27, Epic: 9, Legendary: 2 },
  },
  {
    id: "pack-blue-hour",
    kind: "pack",
    name: "블루 아워 팩",
    description: "레어 이상의 빛이 조금 더 자주 깨어나는 밤바다 팩.",
    price: 220,
    drawCount: 1,
    accent: "#7775FF",
    glyph: "◉",
    rarityWeights: { Common: 38, Rare: 39, Epic: 18, Legendary: 5 },
  },
  {
    id: "pack-deep-current",
    kind: "pack",
    name: "딥 커런트 팩",
    description: "에픽의 파동이 강한 심해빛 프리미엄 팩.",
    price: 360,
    drawCount: 1,
    accent: "#FF7E70",
    glyph: "✦",
    rarityWeights: { Common: 20, Rare: 42, Epic: 29, Legendary: 9 },
  },
];

export const decorItems: DecorItem[] = [
  {
    id: "frame-mint-foam",
    kind: "decor",
    decorType: "frame",
    name: "민트 포말 프레임",
    description: "카드 가장자리에 투명한 포말빛이 흐르는 프레임.",
    price: 180,
    preview: {
      primary: "#59E5D1",
      secondary: "#C8FFF2",
      effect: "bubbles",
    },
  },
  {
    id: "frame-coral-signal",
    kind: "decor",
    decorType: "frame",
    name: "코럴 시그널 프레임",
    description: "산호빛 신호가 모서리마다 번지는 항구 프레임.",
    price: 260,
    preview: {
      primary: "#FF766E",
      secondary: "#FFC174",
      effect: "glow",
    },
  },
  {
    id: "background-midnight-port",
    kind: "decor",
    decorType: "album-background",
    name: "미드나이트 포트",
    description: "깊은 남색 위에 항구의 격자 불빛이 켜지는 앨범 배경.",
    price: 320,
    preview: {
      primary: "#07182E",
      secondary: "#2D69A7",
      effect: "grid",
    },
  },
  {
    id: "background-sunset-tide",
    kind: "decor",
    decorType: "album-background",
    name: "선셋 타이드",
    description: "남빛 앨범 위로 산호색 낙조가 천천히 흐르는 배경.",
    price: 380,
    preview: {
      primary: "#29204D",
      secondary: "#FF776D",
      effect: "shimmer",
    },
  },
];

export const cardById = Object.fromEntries(
  cards.map((card) => [card.id, card]),
) as Record<string, SeaCard>;

export const spotById = Object.fromEntries(
  explorationSpots.map((spot) => [spot.id, spot]),
) as Record<string, ExplorationSpot>;

export const acquisitionByCardId: Record<string, CardAcquisitionRule> =
  cardAcquisitionRules;

export const regionById = Object.fromEntries(
  regions.map((region) => [region.id, region]),
) as Record<RegionId, Region>;
