// 이 파일을 참고해 public/kakao-config.js의 키를 설정하세요. 키는 저장소에 커밋하지 마세요.
// 카카오 개발자 콘솔의 허용 도메인에 실제 서비스 주소를 함께 등록해야 합니다.
window.SEA_K_CONFIG = {
  kakaoJavascriptKey: "여기에_카카오맵_JAVASCRIPT_KEY를_입력하세요",
};
