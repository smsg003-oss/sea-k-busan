// 카카오 개발자 콘솔에서 JavaScript 키를 발급받아 아래 빈 문자열에 입력하세요.
// 허용 도메인에 현재 실행 주소(예: http://localhost:3000)도 등록해야 합니다.
window.SEA_K_CONFIG = {
  kakaoJavascriptKey: "",
};
