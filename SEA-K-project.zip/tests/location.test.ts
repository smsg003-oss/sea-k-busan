import assert from "node:assert/strict";
import test from "node:test";

import {
  acquisitionByCardId,
  explorationSpots,
  spotById,
} from "../app/data";
import {
  distanceMeters,
  evaluateAcquisition,
  nearestRegionId,
} from "../app/location";

test("같은 장소의 거리는 0m로 계산한다", () => {
  const coordinates = explorationSpots[0].coordinates;
  assert.equal(distanceMeters(coordinates, coordinates), 0);
});

test("가장 가까운 부산 바다 지역을 찾는다", () => {
  const haeundae = explorationSpots.find((spot) => spot.id === "haeundae-beach");
  assert.ok(haeundae);
  assert.equal(nearestRegionId(haeundae.coordinates, explorationSpots), "haeundae");
});

test("데모 위치는 오후 6시 기준으로 다대포 노을 조건을 통과한다", () => {
  const rule = acquisitionByCardId["dadaepo-orange-horizon"];
  const spot = spotById[rule.spotId];
  const result = evaluateAcquisition(rule, spot, {
    status: "ready",
    coords: spot.coordinates,
    source: "demo",
  });

  assert.equal(result.eligible, true);
  assert.equal(result.distanceOk, true);
  assert.equal(result.timeOk, true);
  assert.equal(result.effectiveHour, 18);
});

test("실제 위치가 300m 밖이면 촬영 인증을 막는다", () => {
  const rule = acquisitionByCardId["haeundae-foam-letter"];
  const spot = spotById[rule.spotId];
  const result = evaluateAcquisition(
    rule,
    spot,
    {
      status: "ready",
      coords: { lat: 35.1796, lng: 129.0756 },
      source: "gps",
    },
    new Date(2026, 7, 12, 18, 0),
  );

  assert.equal(result.eligible, false);
  assert.equal(result.distanceOk, false);
  assert.match(result.reasons.join(" "), /300m/);
});

test("시간 제한 카드에는 위치와 시간 조건을 모두 적용한다", () => {
  const rule = acquisitionByCardId["dadaepo-orange-horizon"];
  const spot = spotById[rule.spotId];
  const result = evaluateAcquisition(
    rule,
    spot,
    {
      status: "ready",
      coords: spot.coordinates,
      source: "gps",
    },
    new Date(2026, 7, 12, 14, 0),
  );

  assert.equal(result.distanceOk, true);
  assert.equal(result.timeOk, false);
  assert.equal(result.eligible, false);
  assert.match(result.reasons.join(" "), /17:00~20:00/);
});
