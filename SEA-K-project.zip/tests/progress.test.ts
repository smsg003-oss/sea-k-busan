import assert from "node:assert/strict";
import test from "node:test";
import {
  cardById,
  cardPacks,
  decorItems,
  explorationSpots,
  regionRewards,
  tradeListings,
} from "../app/data";
import {
  DEFAULT_PROGRESS,
  buyOrEquipDecor,
  buyPack,
  captureCard,
  completeTrade,
  getLocalDateKey,
  markOnboardingSeen,
  redeemRegionReward,
  safeParseProgress,
  verifySpot,
} from "../app/progress";

function freshProgress() {
  return safeParseProgress(JSON.stringify(DEFAULT_PROGRESS));
}

const FIRST_PHOTO = "data:image/jpeg;base64,aGVsbG8=";
const UPDATED_PHOTO = "data:image/webp;base64,d29ybGQ=";

test("장소 인증은 카드와 코인을 한 번만 지급한다", () => {
  const spot = explorationSpots[0];
  const date = new Date(2026, 7, 12, 10, 0, 0);
  const first = verifySpot(freshProgress(), spot, date, () => 0);

  assert.equal(first.ok, true);
  if (!first.ok) return;
  assert.equal(first.coins, spot.coinReward.min);
  assert.equal(first.state.verifications[spot.id], getLocalDateKey(date));
  assert.equal(first.state.cards[first.card.id], (DEFAULT_PROGRESS.cards[first.card.id] ?? 0) + 1);

  const second = verifySpot(first.state, spot, date, () => 0);
  assert.deepEqual(second, { ok: false, reason: "오늘은 이미 이 장소를 인증했어요." });
});

test("카드팩 구매는 가격을 차감하고 중복도 정상 누적한다", () => {
  const pack = cardPacks[0];
  const state = freshProgress();
  const result = buyPack(state, pack, () => 0);

  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.state.coins, state.coins - pack.price);
  assert.equal(result.state.cards[result.card.id], (state.cards[result.card.id] ?? 0) + 1);
});

test("꾸미기 아이템은 구매 후 즉시 적용되고 재적용에는 코인이 들지 않는다", () => {
  const item = decorItems[0];
  const state = freshProgress();
  const purchase = buyOrEquipDecor(state, item);

  assert.equal(purchase.ok, true);
  if (!purchase.ok) return;
  assert.equal(purchase.action, "purchased");
  assert.equal(purchase.state.coins, state.coins - item.price);
  assert.equal(purchase.state.activeFrame, item.id);

  const equip = buyOrEquipDecor(purchase.state, item);
  assert.equal(equip.ok, true);
  if (!equip.ok) return;
  assert.equal(equip.action, "equipped");
  assert.equal(equip.state.coins, purchase.state.coins);
});

test("가상 교환은 제공 카드를 제거하고 새 카드와 추가 코인을 반영한다", () => {
  const listing = tradeListings[0];
  const state = freshProgress();
  const beforeWanted = state.cards[listing.wantedCardId];
  const beforeOffered = state.cards[listing.offeredCardId] ?? 0;
  const result = completeTrade(state, listing);

  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.receivedCard, cardById[listing.offeredCardId]);
  assert.equal(result.state.cards[listing.wantedCardId], beforeWanted - 1);
  assert.equal(result.state.cards[listing.offeredCardId], beforeOffered + 1);
  assert.equal(result.state.coins, state.coins + listing.bonusCoins);
  assert.ok(result.state.completedTrades.includes(listing.id));
});

test("손상된 로컬 데이터는 안전한 기본 상태로 복구한다", () => {
  assert.deepEqual(safeParseProgress("not-json"), DEFAULT_PROGRESS);
});

test("v1 진행 데이터는 기존 기록을 유지하며 v2 상태로 마이그레이션한다", () => {
  const cardId = "haeundae-foam-letter";
  const spotId = explorationSpots[0].id;
  const tradeId = tradeListings[0].id;
  const decorId = decorItems[0].id;
  const migrated = safeParseProgress({
    version: 1,
    coins: 321,
    cards: { [cardId]: 4 },
    verifications: { [spotId]: "2026-08-12" },
    completedTrades: [tradeId],
    ownedDecor: [decorId],
    activeFrame: decorId,
    activeBackground: null,
  });

  assert.equal(migrated.version, 2);
  assert.equal(migrated.coins, 321);
  assert.deepEqual(migrated.cards, { [cardId]: 4 });
  assert.deepEqual(migrated.verifications, { [spotId]: "2026-08-12" });
  assert.deepEqual(migrated.completedTrades, [tradeId]);
  assert.deepEqual(migrated.ownedDecor, [decorId]);
  assert.equal(migrated.activeFrame, decorId);
  assert.deepEqual(migrated.cardPhotos, {});
  assert.deepEqual(migrated.photoCaptures, {});
  assert.deepEqual(migrated.ownedRewards, []);
  assert.equal(migrated.onboardingSeen, false);
});

test("저장 데이터에서 알 수 없는 ID, 잘못된 사진, 중복 보상을 제거한다", () => {
  const cardId = "haeundae-foam-letter";
  const rewardId = regionRewards[0].id;
  const parsed = safeParseProgress({
    ...DEFAULT_PROGRESS,
    cardPhotos: {
      [cardId]: FIRST_PHOTO,
      "gwangalli-night-current": "data:image/gif;base64,aGVsbG8=",
      "dadaepo-orange-horizon": "data:image/png;base64,%%%",
      "unknown-card": FIRST_PHOTO,
    },
    photoCaptures: {
      [cardId]: "2026-08-12",
      "gwangalli-night-current": "2026-02-31",
      "unknown-card": "2026-08-12",
    },
    ownedRewards: [rewardId, rewardId, "unknown-reward"],
    completedTrades: [tradeListings[0].id, "unknown-trade"],
    verifications: {
      [explorationSpots[0].id]: "2026-08-12",
      "unknown-spot": "2026-08-12",
    },
  });

  assert.deepEqual(parsed.cardPhotos, { [cardId]: FIRST_PHOTO });
  assert.deepEqual(parsed.photoCaptures, { [cardId]: "2026-08-12" });
  assert.deepEqual(parsed.ownedRewards, [rewardId]);
  assert.deepEqual(parsed.completedTrades, [tradeListings[0].id]);
  assert.deepEqual(parsed.verifications, {
    [explorationSpots[0].id]: "2026-08-12",
  });
});

test("첫 사진 촬영만 카드와 코인을 지급하고 재촬영은 대표 사진만 교체한다", () => {
  const card = cardById["haeundae-foam-letter"];
  const state = freshProgress();
  const initialCount = state.cards[card.id] ?? 0;
  const firstDate = new Date(2026, 7, 12, 18, 0, 0);
  const first = captureCard(state, card, FIRST_PHOTO, 90, firstDate);

  assert.equal(first.ok, true);
  if (!first.ok) return;
  assert.equal(first.isFirstCapture, true);
  assert.equal(first.coins, 90);
  assert.equal(first.state.coins, state.coins + 90);
  assert.equal(first.state.cards[card.id], initialCount + 1);
  assert.equal(first.state.cardPhotos[card.id], FIRST_PHOTO);
  assert.equal(first.state.photoCaptures[card.id], getLocalDateKey(firstDate));
  assert.equal(state.cardPhotos[card.id], undefined);

  const secondDate = new Date(2026, 7, 13, 9, 0, 0);
  const second = captureCard(first.state, card, UPDATED_PHOTO, 150, secondDate);

  assert.equal(second.ok, true);
  if (!second.ok) return;
  assert.equal(second.isFirstCapture, false);
  assert.equal(second.coins, 0);
  assert.equal(second.state.coins, first.state.coins);
  assert.equal(second.state.cards[card.id], first.state.cards[card.id]);
  assert.equal(second.state.cardPhotos[card.id], UPDATED_PHOTO);
  assert.equal(second.state.photoCaptures[card.id], getLocalDateKey(secondDate));
});

test("같은 장소의 촬영 인증은 대표 사진 교체를 포함해 하루 한 번만 허용한다", () => {
  const firstCard = cardById["haeundae-foam-letter"];
  const secondCard = cardById["haeundae-blue-hour"];
  const spotId = "haeundae-beach";
  const date = new Date(2026, 7, 12, 18, 0, 0);
  const first = captureCard(freshProgress(), firstCard, FIRST_PHOTO, 80, date, spotId);

  assert.equal(first.ok, true);
  if (!first.ok) return;
  assert.equal(first.state.verifications[spotId], getLocalDateKey(date));

  const blocked = captureCard(first.state, secondCard, UPDATED_PHOTO, 130, date, spotId);
  assert.deepEqual(blocked, {
    ok: false,
    reason: "오늘은 이미 이 장소에서 카드를 획득했어요. 내일 다시 탐험해 주세요.",
  });

  const recaptured = captureCard(first.state, firstCard, UPDATED_PHOTO, 80, date, spotId);
  assert.deepEqual(recaptured, {
    ok: false,
    reason: "오늘은 이미 이 장소에서 카드를 획득했어요. 내일 다시 탐험해 주세요.",
  });

  const nextDay = new Date(2026, 7, 13, 18, 0, 0);
  const updated = captureCard(first.state, firstCard, UPDATED_PHOTO, 80, nextDay, spotId);
  assert.equal(updated.ok, true);
  if (!updated.ok) return;
  assert.equal(updated.coins, 0);
  assert.equal(updated.state.cardPhotos[firstCard.id], UPDATED_PHOTO);
});

test("사진 촬영은 지원하지 않는 데이터 URL을 거부한다", () => {
  const state = freshProgress();
  const card = cardById["haeundae-foam-letter"];

  assert.equal(captureCard(state, card, "data:image/gif;base64,aGVsbG8=", 80).ok, false);
  assert.equal(captureCard(state, card, "data:image/png;base64,%%%", 80).ok, false);
  assert.equal(captureCard(state, card, "https://example.com/photo.jpg", 80).ok, false);
});

test("지역 보상은 코인을 차감해 한 번만 교환할 수 있다", () => {
  const reward = regionRewards[0];
  const state = { ...freshProgress(), coins: reward.price + 20 };
  const result = redeemRegionReward(state, reward);

  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.state.coins, 20);
  assert.deepEqual(result.state.ownedRewards, [reward.id]);

  const duplicate = redeemRegionReward(result.state, reward);
  assert.deepEqual(duplicate, {
    ok: false,
    reason: "이미 교환한 지역 보상입니다.",
  });

  const insufficient = redeemRegionReward({ ...freshProgress(), coins: reward.price - 1 }, reward);
  assert.deepEqual(insufficient, { ok: false, reason: "코인이 부족합니다." });
});

test("온보딩 확인 상태와 새 v2 필드는 기존 액션 이후에도 유지된다", () => {
  const card = cardById["haeundae-foam-letter"];
  const rewardId = regionRewards[0].id;
  const seeded = markOnboardingSeen({
    ...freshProgress(),
    cardPhotos: { [card.id]: FIRST_PHOTO },
    photoCaptures: { [card.id]: "2026-08-12" },
    ownedRewards: [rewardId],
  });

  const assertV2Fields = (state: typeof seeded) => {
    assert.equal(state.onboardingSeen, true);
    assert.deepEqual(state.cardPhotos, seeded.cardPhotos);
    assert.deepEqual(state.photoCaptures, seeded.photoCaptures);
    assert.deepEqual(state.ownedRewards, seeded.ownedRewards);
  };

  const verified = verifySpot(seeded, explorationSpots[0], new Date(2026, 7, 13), () => 0);
  assert.equal(verified.ok, true);
  if (verified.ok) assertV2Fields(verified.state);

  const packed = buyPack(seeded, cardPacks[0], () => 0);
  assert.equal(packed.ok, true);
  if (packed.ok) assertV2Fields(packed.state);

  const decorated = buyOrEquipDecor(seeded, decorItems[0]);
  assert.equal(decorated.ok, true);
  if (decorated.ok) assertV2Fields(decorated.state);

  const traded = completeTrade(seeded, tradeListings[0]);
  assert.equal(traded.ok, true);
  if (traded.ok) assertV2Fields(traded.state);
});
